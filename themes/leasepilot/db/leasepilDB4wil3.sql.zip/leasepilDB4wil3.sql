-- phpMyAdmin SQL Dump
-- version 4.4.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 16, 2018 at 09:15 PM
-- Server version: 5.6.24
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `leasepilDB4wil3`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-05-02 18:19:49', '2018-05-02 18:19:49', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB AUTO_INCREMENT=396 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://leasepilot.dev.cc', 'yes'),
(2, 'home', 'http://leasepilot.dev.cc', 'yes'),
(3, 'blogname', 'LeasePilot', 'yes'),
(4, 'blogdescription', 'Rethinking the commercial real estate lease', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'tu@delindesign.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:139:{s:13:"case-study/?$";s:30:"index.php?post_type=case-study";s:43:"case-study/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?post_type=case-study&feed=$matches[1]";s:38:"case-study/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?post_type=case-study&feed=$matches[1]";s:30:"case-study/page/([0-9]{1,})/?$";s:48:"index.php?post_type=case-study&paged=$matches[1]";s:11:"resource/?$";s:28:"index.php?post_type=resource";s:41:"resource/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=resource&feed=$matches[1]";s:36:"resource/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=resource&feed=$matches[1]";s:28:"resource/page/([0-9]{1,})/?$";s:46:"index.php?post_type=resource&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:38:"case-study/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:48:"case-study/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:68:"case-study/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"case-study/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"case-study/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"case-study/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:27:"case-study/([^/]+)/embed/?$";s:43:"index.php?case-study=$matches[1]&embed=true";s:31:"case-study/([^/]+)/trackback/?$";s:37:"index.php?case-study=$matches[1]&tb=1";s:51:"case-study/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?case-study=$matches[1]&feed=$matches[2]";s:46:"case-study/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?case-study=$matches[1]&feed=$matches[2]";s:39:"case-study/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?case-study=$matches[1]&paged=$matches[2]";s:46:"case-study/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?case-study=$matches[1]&cpage=$matches[2]";s:35:"case-study/([^/]+)(?:/([0-9]+))?/?$";s:49:"index.php?case-study=$matches[1]&page=$matches[2]";s:27:"case-study/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"case-study/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"case-study/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"case-study/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"case-study/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"case-study/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"resource/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"resource/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"resource/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"resource/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"resource/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"resource/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"resource/([^/]+)/embed/?$";s:41:"index.php?resource=$matches[1]&embed=true";s:29:"resource/([^/]+)/trackback/?$";s:35:"index.php?resource=$matches[1]&tb=1";s:49:"resource/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?resource=$matches[1]&feed=$matches[2]";s:44:"resource/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?resource=$matches[1]&feed=$matches[2]";s:37:"resource/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?resource=$matches[1]&paged=$matches[2]";s:44:"resource/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?resource=$matches[1]&cpage=$matches[2]";s:33:"resource/([^/]+)(?:/([0-9]+))?/?$";s:47:"index.php?resource=$matches[1]&page=$matches[2]";s:25:"resource/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"resource/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"resource/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"resource/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"resource/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"resource/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:58:"resource-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:56:"index.php?resource-category=$matches[1]&feed=$matches[2]";s:53:"resource-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:56:"index.php?resource-category=$matches[1]&feed=$matches[2]";s:34:"resource-category/([^/]+)/embed/?$";s:50:"index.php?resource-category=$matches[1]&embed=true";s:46:"resource-category/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?resource-category=$matches[1]&paged=$matches[2]";s:28:"resource-category/([^/]+)/?$";s:39:"index.php?resource-category=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'leasepilot', 'yes'),
(41, 'stylesheet', 'leasepilot', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '144', 'yes'),
(84, 'page_on_front', '5', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:9:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-widgets";a:0:{}s:15:"footer-widget-1";a:1:{i:0;s:10:"nav_menu-2";}s:15:"footer-widget-2";a:1:{i:0;s:10:"nav_menu-3";}s:15:"footer-widget-3";a:1:{i:0;s:10:"nav_menu-4";}s:15:"footer-widget-4";a:1:{i:0;s:10:"nav_menu-5";}s:15:"footer-widget-5";a:0:{}s:15:"footer-widget-6";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:5:{i:2;a:1:{s:8:"nav_menu";i:7;}i:3;a:1:{s:8:"nav_menu";i:8;}i:4;a:1:{s:8:"nav_menu";i:9;}i:5;a:1:{s:8:"nav_menu";i:10;}s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'cron', 'a:4:{i:1526537989;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1526562629;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1526581263;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(110, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1525286349;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(121, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.5.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.5.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.9.5-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.9.5-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.9.5";s:7:"version";s:5:"4.9.5";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1526494806;s:15:"version_checked";s:5:"4.9.5";s:12:"translations";a:0:{}}', 'no'),
(124, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:18:"tu@delindesign.com";s:7:"version";s:5:"4.9.5";s:9:"timestamp";i:1525285260;}', 'no'),
(130, 'can_compress_scripts', '1', 'no'),
(144, 'recently_activated', 'a:0:{}', 'yes'),
(145, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1526494808;s:7:"checked";a:1:{s:10:"leasepilot";s:5:"1.0.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'no'),
(146, 'current_theme', 'LeasePilot Theme', 'yes'),
(147, 'theme_mods_leasepilot-theme', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1525289875;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"footer-widgets";a:0:{}}}}', 'yes'),
(148, 'theme_switched', '', 'yes'),
(152, 'theme_mods_leasepilot', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:9:"top-bar-r";i:2;s:10:"mobile-nav";i:2;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(164, 'category_children', 'a:0:{}', 'yes'),
(165, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(171, 'WPLANG', '', 'yes'),
(172, 'new_admin_email', 'tu@delindesign.com', 'yes'),
(253, '_site_transient_timeout_browser_5df888fd2d0fe4df7fd67885402ecf35', '1526583944', 'no'),
(254, '_site_transient_browser_5df888fd2d0fe4df7fd67885402ecf35', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:13:"66.0.3359.139";s:8:"platform";s:9:"Macintosh";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'no'),
(292, '_site_transient_timeout_browser_8e6691aa4674186fe1311f1e1dea6ed2', '1526771983', 'no'),
(293, '_site_transient_browser_8e6691aa4674186fe1311f1e1dea6ed2', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:13:"66.0.3359.139";s:8:"platform";s:9:"Macintosh";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'no'),
(313, 'acf_version', '5.6.10', 'yes'),
(316, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3NjoiYjNKa1pYSmZhV1E5TVRBeE1ETTFmSFI1Y0dVOVpHVjJaV3h2Y0dWeWZHUmhkR1U5TWpBeE55MHdNeTB3TWlBeU1EbzFOam94TWc9PSI7czozOiJ1cmwiO3M6MjQ6Imh0dHA6Ly9sZWFzZXBpbG90LmRldi5jYyI7fQ==', 'yes'),
(324, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1526494808;s:7:"checked";a:2:{s:34:"advanced-custom-fields-pro/acf.php";s:6:"5.6.10";s:47:"regenerate-thumbnails/regenerate-thumbnails.php";s:5:"3.0.2";}s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:1:{s:47:"regenerate-thumbnails/regenerate-thumbnails.php";O:8:"stdClass":9:{s:2:"id";s:35:"w.org/plugins/regenerate-thumbnails";s:4:"slug";s:21:"regenerate-thumbnails";s:6:"plugin";s:47:"regenerate-thumbnails/regenerate-thumbnails.php";s:11:"new_version";s:5:"3.0.2";s:3:"url";s:52:"https://wordpress.org/plugins/regenerate-thumbnails/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/regenerate-thumbnails.zip";s:5:"icons";a:1:{s:2:"1x";s:74:"https://ps.w.org/regenerate-thumbnails/assets/icon-128x128.png?rev=1753390";}s:7:"banners";a:2:{s:2:"2x";s:77:"https://ps.w.org/regenerate-thumbnails/assets/banner-1544x500.jpg?rev=1753390";s:2:"1x";s:76:"https://ps.w.org/regenerate-thumbnails/assets/banner-772x250.jpg?rev=1753390";}s:11:"banners_rtl";a:0:{}}}}', 'no'),
(344, 'options_page_subheading', 'LeasePilot combines document automation, word processing |and user-centric interfaces into a single web-based platform, expressly designed to radically accelerate the entire process.', 'no'),
(345, '_options_page_subheading', 'field_5af83db84808e', 'no'),
(346, 'options_background', 'image', 'no'),
(347, '_options_background', 'field_5af83c494f983', 'no'),
(348, 'options_background_image', '73', 'no'),
(349, '_options_background_image', 'field_5af83ccd4f985', 'no'),
(350, 'options_archive_page_title', 'Case Studies', 'no'),
(351, '_options_archive_page_title', 'field_5af9c5b0a558d', 'no'),
(359, 'options_resource_archive_page_title', 'Resources', 'no'),
(360, '_options_resource_archive_page_title', 'field_5af9db8dde5ea', 'no'),
(361, 'options_case_study_archive_page_title', 'Case Studies', 'no'),
(362, '_options_case_study_archive_page_title', 'field_5af9c5b0a558d', 'no'),
(377, 'resource-category_children', 'a:0:{}', 'yes'),
(393, '_site_transient_timeout_theme_roots', '1526496608', 'no'),
(394, '_site_transient_theme_roots', 'a:1:{s:10:"leasepilot";s:7:"/themes";}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB AUTO_INCREMENT=1183 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(5, 5, '_edit_last', '1'),
(6, 5, '_edit_lock', '1526495549:1'),
(7, 5, '_wp_page_template', 'page-templates/front.php'),
(8, 7, '_edit_last', '1'),
(9, 7, '_edit_lock', '1525356611:1'),
(10, 8, '_edit_last', '1'),
(11, 8, '_wp_page_template', 'default'),
(12, 8, '_edit_lock', '1525355662:1'),
(13, 10, '_edit_last', '1'),
(14, 10, '_wp_page_template', 'page-templates/page-about.php'),
(15, 10, '_edit_lock', '1526477582:1'),
(16, 12, '_edit_last', '1'),
(17, 12, '_edit_lock', '1526411014:1'),
(18, 7, '_wp_old_slug', 'title-goes-here'),
(19, 12, '_wp_old_slug', 'title-goes-here'),
(20, 13, '_menu_item_type', 'post_type'),
(21, 13, '_menu_item_menu_item_parent', '0'),
(22, 13, '_menu_item_object_id', '10'),
(23, 13, '_menu_item_object', 'page'),
(24, 13, '_menu_item_target', ''),
(25, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(26, 13, '_menu_item_xfn', ''),
(27, 13, '_menu_item_url', ''),
(29, 14, '_menu_item_type', 'post_type'),
(30, 14, '_menu_item_menu_item_parent', '0'),
(31, 14, '_menu_item_object_id', '8'),
(32, 14, '_menu_item_object', 'page'),
(33, 14, '_menu_item_target', ''),
(34, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(35, 14, '_menu_item_xfn', ''),
(36, 14, '_menu_item_url', ''),
(56, 17, '_menu_item_type', 'custom'),
(57, 17, '_menu_item_menu_item_parent', '0'),
(58, 17, '_menu_item_object_id', '17'),
(59, 17, '_menu_item_object', 'custom'),
(60, 17, '_menu_item_target', ''),
(61, 17, '_menu_item_classes', 'a:1:{i:0;s:11:"button-menu";}'),
(62, 17, '_menu_item_xfn', ''),
(63, 17, '_menu_item_url', '/request-a-demo'),
(65, 18, '_edit_last', '1'),
(66, 18, '_wp_page_template', 'default'),
(67, 18, '_edit_lock', '1525365338:1'),
(86, 22, '_menu_item_type', 'custom'),
(87, 22, '_menu_item_menu_item_parent', '0'),
(88, 22, '_menu_item_object_id', '22'),
(89, 22, '_menu_item_object', 'custom'),
(90, 22, '_menu_item_target', ''),
(91, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(92, 22, '_menu_item_xfn', ''),
(93, 22, '_menu_item_url', '/login'),
(100, 25, '_wp_attached_file', '2018/05/casto-cover.png'),
(101, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:225;s:4:"file";s:23:"2018/05/casto-cover.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"casto-cover-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:23:"casto-cover-200x205.png";s:5:"width";i:200;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:14:"featured-small";a:4:{s:4:"file";s:23:"casto-cover-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(102, 26, '_wp_attached_file', '2018/05/casto.png'),
(103, 26, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:664;s:6:"height";i:220;s:4:"file";s:17:"2018/05/casto.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"casto-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"casto-300x99.png";s:5:"width";i:300;s:6:"height";i:99;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:17:"casto-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:14:"featured-small";a:4:{s:4:"file";s:17:"casto-640x200.png";s:5:"width";i:640;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:8:"fp-small";a:4:{s:4:"file";s:17:"casto-640x212.png";s:5:"width";i:640;s:6:"height";i:212;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(104, 27, '_wp_attached_file', '2018/05/entrata.png'),
(105, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:616;s:6:"height";i:120;s:4:"file";s:19:"2018/05/entrata.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"entrata-150x120.png";s:5:"width";i:150;s:6:"height";i:120;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"entrata-300x58.png";s:5:"width";i:300;s:6:"height";i:58;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:19:"entrata-400x120.png";s:5:"width";i:400;s:6:"height";i:120;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(106, 28, '_wp_attached_file', '2018/05/nestio.png'),
(107, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:700;s:6:"height";i:144;s:4:"file";s:18:"2018/05/nestio.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"nestio-150x144.png";s:5:"width";i:150;s:6:"height";i:144;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"nestio-300x62.png";s:5:"width";i:300;s:6:"height";i:62;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:18:"nestio-400x144.png";s:5:"width";i:400;s:6:"height";i:144;s:9:"mime-type";s:9:"image/png";}s:14:"featured-small";a:4:{s:4:"file";s:18:"nestio-640x144.png";s:5:"width";i:640;s:6:"height";i:144;s:9:"mime-type";s:9:"image/png";}s:8:"fp-small";a:4:{s:4:"file";s:18:"nestio-640x132.png";s:5:"width";i:640;s:6:"height";i:132;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(108, 29, '_wp_attached_file', '2018/05/real-estate-software.png'),
(109, 29, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:424;s:6:"height";i:224;s:4:"file";s:32:"2018/05/real-estate-software.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"real-estate-software-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:32:"real-estate-software-300x158.png";s:5:"width";i:300;s:6:"height";i:158;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:32:"real-estate-software-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:14:"featured-small";a:4:{s:4:"file";s:32:"real-estate-software-424x200.png";s:5:"width";i:424;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(110, 30, '_wp_attached_file', '2018/05/vts.png'),
(111, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:344;s:6:"height";i:356;s:4:"file";s:15:"2018/05/vts.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"vts-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:15:"vts-290x300.png";s:5:"width";i:290;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:15:"vts-344x205.png";s:5:"width";i:344;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:14:"featured-small";a:4:{s:4:"file";s:15:"vts-344x200.png";s:5:"width";i:344;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(112, 31, '_wp_attached_file', '2018/05/yardi.png'),
(113, 31, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:628;s:6:"height";i:156;s:4:"file";s:17:"2018/05/yardi.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"yardi-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"yardi-300x75.png";s:5:"width";i:300;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:17:"yardi-400x156.png";s:5:"width";i:400;s:6:"height";i:156;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(126, 34, '_edit_last', '1'),
(127, 34, '_edit_lock', '1526317618:1'),
(129, 35, '_edit_last', '1'),
(130, 35, '_edit_lock', '1526317566:1'),
(132, 36, '_edit_last', '1'),
(133, 36, '_edit_lock', '1526317549:1'),
(135, 37, '_edit_last', '1'),
(136, 37, '_edit_lock', '1526495344:1'),
(138, 38, '_edit_last', '1'),
(139, 38, '_edit_lock', '1526317512:1'),
(141, 39, '_edit_last', '1'),
(142, 39, '_edit_lock', '1526410701:1'),
(144, 40, '_menu_item_type', 'custom'),
(145, 40, '_menu_item_menu_item_parent', '0'),
(146, 40, '_menu_item_object_id', '40'),
(147, 40, '_menu_item_object', 'custom'),
(148, 40, '_menu_item_target', ''),
(149, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(150, 40, '_menu_item_xfn', ''),
(151, 40, '_menu_item_url', '/blog'),
(153, 41, '_menu_item_type', 'post_type'),
(154, 41, '_menu_item_menu_item_parent', '0'),
(155, 41, '_menu_item_object_id', '8'),
(156, 41, '_menu_item_object', 'page'),
(157, 41, '_menu_item_target', ''),
(158, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(159, 41, '_menu_item_xfn', ''),
(160, 41, '_menu_item_url', ''),
(162, 42, '_menu_item_type', 'custom'),
(163, 42, '_menu_item_menu_item_parent', '41'),
(164, 42, '_menu_item_object_id', '42'),
(165, 42, '_menu_item_object', 'custom'),
(166, 42, '_menu_item_target', ''),
(167, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(168, 42, '_menu_item_xfn', ''),
(169, 42, '_menu_item_url', '/#!'),
(171, 43, '_menu_item_type', 'custom'),
(172, 43, '_menu_item_menu_item_parent', '41'),
(173, 43, '_menu_item_object_id', '43'),
(174, 43, '_menu_item_object', 'custom'),
(175, 43, '_menu_item_target', ''),
(176, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(177, 43, '_menu_item_xfn', ''),
(178, 43, '_menu_item_url', '/#!'),
(180, 44, '_menu_item_type', 'custom'),
(181, 44, '_menu_item_menu_item_parent', '41'),
(182, 44, '_menu_item_object_id', '44'),
(183, 44, '_menu_item_object', 'custom'),
(184, 44, '_menu_item_target', ''),
(185, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(186, 44, '_menu_item_xfn', ''),
(187, 44, '_menu_item_url', '/#!'),
(189, 45, '_menu_item_type', 'post_type'),
(190, 45, '_menu_item_menu_item_parent', '0'),
(191, 45, '_menu_item_object_id', '10'),
(192, 45, '_menu_item_object', 'page'),
(193, 45, '_menu_item_target', ''),
(194, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(195, 45, '_menu_item_xfn', ''),
(196, 45, '_menu_item_url', ''),
(198, 46, '_menu_item_type', 'custom'),
(199, 46, '_menu_item_menu_item_parent', '45'),
(200, 46, '_menu_item_object_id', '46'),
(201, 46, '_menu_item_object', 'custom'),
(202, 46, '_menu_item_target', ''),
(203, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(204, 46, '_menu_item_xfn', ''),
(205, 46, '_menu_item_url', '/#!'),
(207, 47, '_menu_item_type', 'custom'),
(208, 47, '_menu_item_menu_item_parent', '0'),
(209, 47, '_menu_item_object_id', '47'),
(210, 47, '_menu_item_object', 'custom'),
(211, 47, '_menu_item_target', ''),
(212, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(213, 47, '_menu_item_xfn', ''),
(214, 47, '_menu_item_url', '/case-study'),
(216, 48, '_menu_item_type', 'custom'),
(217, 48, '_menu_item_menu_item_parent', '0'),
(218, 48, '_menu_item_object_id', '48'),
(219, 48, '_menu_item_object', 'custom'),
(220, 48, '_menu_item_target', ''),
(221, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(222, 48, '_menu_item_xfn', ''),
(223, 48, '_menu_item_url', '/resource'),
(225, 50, '_edit_last', '1'),
(226, 50, '_edit_lock', '1526495379:1'),
(227, 56, '_wp_attached_file', '2018/05/about-cover.png'),
(228, 56, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:614;s:4:"file";s:23:"2018/05/about-cover.png";s:5:"sizes";a:13:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"about-cover-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"about-cover-300x154.png";s:5:"width";i:300;s:6:"height";i:154;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:23:"about-cover-768x393.png";s:5:"width";i:768;s:6:"height";i:393;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:24:"about-cover-1024x524.png";s:5:"width";i:1024;s:6:"height";i:524;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:23:"about-cover-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:11:"cover_large";a:4:{s:4:"file";s:24:"about-cover-1200x614.png";s:5:"width";i:1200;s:6:"height";i:614;s:9:"mime-type";s:9:"image/png";}s:14:"featured-small";a:4:{s:4:"file";s:23:"about-cover-640x200.png";s:5:"width";i:640;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:15:"featured-medium";a:4:{s:4:"file";s:24:"about-cover-1200x400.png";s:5:"width";i:1200;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";}s:14:"featured-large";a:4:{s:4:"file";s:24:"about-cover-1200x400.png";s:5:"width";i:1200;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";}s:15:"featured-xlarge";a:4:{s:4:"file";s:24:"about-cover-1200x400.png";s:5:"width";i:1200;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";}s:8:"fp-small";a:4:{s:4:"file";s:23:"about-cover-640x327.png";s:5:"width";i:640;s:6:"height";i:327;s:9:"mime-type";s:9:"image/png";}s:9:"fp-medium";a:4:{s:4:"file";s:24:"about-cover-1024x524.png";s:5:"width";i:1024;s:6:"height";i:524;s:9:"mime-type";s:9:"image/png";}s:8:"fp-large";a:4:{s:4:"file";s:24:"about-cover-1200x614.png";s:5:"width";i:1200;s:6:"height";i:614;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(229, 10, 'page_subheading', '<span style="color: #3c4542;">LeasePilot’s management team blends deep legal insights with the technological vision.</span>'),
(230, 10, '_page_subheading', 'field_5af83db84808e'),
(231, 10, 'background', 'image'),
(232, 10, '_background', 'field_5af83c494f983'),
(233, 10, 'background_image', '56'),
(234, 10, '_background_image', 'field_5af83ccd4f985'),
(235, 57, 'page_subheading', 'LeasePilot’s management team blends deep legal insights with the technological vision.'),
(236, 57, '_page_subheading', 'field_5af83db84808e'),
(237, 57, 'background', 'image'),
(238, 57, '_background', 'field_5af83c494f983'),
(239, 57, 'background_image', '56'),
(240, 57, '_background_image', 'field_5af83ccd4f985'),
(241, 56, '_edit_lock', '1526218526:1'),
(242, 58, '_wp_attached_file', '2018/05/Gabriel.png'),
(243, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:566;s:6:"height";i:566;s:4:"file";s:19:"2018/05/Gabriel.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"Gabriel-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"Gabriel-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:19:"Gabriel-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(244, 59, '_wp_attached_file', '2018/05/Itzik.png'),
(245, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:566;s:6:"height";i:566;s:4:"file";s:17:"2018/05/Itzik.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"Itzik-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"Itzik-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:17:"Itzik-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(246, 60, '_wp_attached_file', '2018/05/Nadine.png'),
(247, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:566;s:6:"height";i:566;s:4:"file";s:18:"2018/05/Nadine.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"Nadine-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"Nadine-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:18:"Nadine-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(248, 61, '_edit_last', '1'),
(249, 61, '_edit_lock', '1526351540:1'),
(250, 10, 'people_0_avatar', '58'),
(251, 10, '_people_0_avatar', 'field_5af9957ee81b9'),
(252, 10, 'people_0_first_name', 'Gabriel'),
(253, 10, '_people_0_first_name', 'field_5af99594e81ba'),
(254, 10, 'people_0_last_name', 'Safar'),
(255, 10, '_people_0_last_name', 'field_5af995b2e81bb'),
(256, 10, 'people_0_position', 'Co-founder, CEO'),
(257, 10, '_people_0_position', 'field_5af995c2e81bc'),
(258, 10, 'people_1_avatar', '59'),
(259, 10, '_people_1_avatar', 'field_5af9957ee81b9'),
(260, 10, 'people_1_first_name', 'Itzik'),
(261, 10, '_people_1_first_name', 'field_5af99594e81ba'),
(262, 10, 'people_1_last_name', 'Spitzen'),
(263, 10, '_people_1_last_name', 'field_5af995b2e81bb'),
(264, 10, 'people_1_position', 'Co-founder, CTO'),
(265, 10, '_people_1_position', 'field_5af995c2e81bc'),
(266, 10, 'people_2_avatar', '60'),
(267, 10, '_people_2_avatar', 'field_5af9957ee81b9'),
(268, 10, 'people_2_first_name', 'Nadine'),
(269, 10, '_people_2_first_name', 'field_5af99594e81ba'),
(270, 10, 'people_2_last_name', 'Ezzie'),
(271, 10, '_people_2_last_name', 'field_5af995b2e81bb'),
(272, 10, 'people_2_position', 'Director of Customer Success'),
(273, 10, '_people_2_position', 'field_5af995c2e81bc'),
(274, 10, 'people', '3'),
(275, 10, '_people', 'field_5af99562e81b8'),
(276, 67, 'page_subheading', 'LeasePilot’s management team blends deep legal insights with the technological vision.'),
(277, 67, '_page_subheading', 'field_5af83db84808e'),
(278, 67, 'background', 'image'),
(279, 67, '_background', 'field_5af83c494f983'),
(280, 67, 'background_image', '56'),
(281, 67, '_background_image', 'field_5af83ccd4f985'),
(282, 67, 'people_0_avatar', '58'),
(283, 67, '_people_0_avatar', 'field_5af9957ee81b9'),
(284, 67, 'people_0_first_name', 'Gabriel'),
(285, 67, '_people_0_first_name', 'field_5af99594e81ba'),
(286, 67, 'people_0_last_name', 'Safar'),
(287, 67, '_people_0_last_name', 'field_5af995b2e81bb'),
(288, 67, 'people_0_position', 'Co-founder, CEO'),
(289, 67, '_people_0_position', 'field_5af995c2e81bc'),
(290, 67, 'people_1_avatar', '59'),
(291, 67, '_people_1_avatar', 'field_5af9957ee81b9'),
(292, 67, 'people_1_first_name', 'Itzik'),
(293, 67, '_people_1_first_name', 'field_5af99594e81ba'),
(294, 67, 'people_1_last_name', 'Spitzen'),
(295, 67, '_people_1_last_name', 'field_5af995b2e81bb'),
(296, 67, 'people_1_position', 'Co-founder, CTO'),
(297, 67, '_people_1_position', 'field_5af995c2e81bc'),
(298, 67, 'people_2_avatar', '60'),
(299, 67, '_people_2_avatar', 'field_5af9957ee81b9'),
(300, 67, 'people_2_first_name', 'Nadine'),
(301, 67, '_people_2_first_name', 'field_5af99594e81ba'),
(302, 67, 'people_2_last_name', 'Ezzie'),
(303, 67, '_people_2_last_name', 'field_5af995b2e81bb'),
(304, 67, 'people_2_position', 'Director of Customer Success'),
(305, 67, '_people_2_position', 'field_5af995c2e81bc'),
(306, 67, 'people', '3'),
(307, 67, '_people', 'field_5af99562e81b8'),
(308, 10, 'people_0_name_separator', ''),
(309, 10, '_people_0_name_separator', 'field_5af99685b6681'),
(310, 10, 'people_1_name_separator', ''),
(311, 10, '_people_1_name_separator', 'field_5af99685b6681'),
(312, 10, 'people_2_name_separator', '-'),
(313, 10, '_people_2_name_separator', 'field_5af99685b6681'),
(314, 69, 'page_subheading', 'LeasePilot’s management team blends deep legal insights with the technological vision.'),
(315, 69, '_page_subheading', 'field_5af83db84808e'),
(316, 69, 'background', 'image'),
(317, 69, '_background', 'field_5af83c494f983'),
(318, 69, 'background_image', '56'),
(319, 69, '_background_image', 'field_5af83ccd4f985'),
(320, 69, 'people_0_avatar', '58'),
(321, 69, '_people_0_avatar', 'field_5af9957ee81b9'),
(322, 69, 'people_0_first_name', 'Gabriel'),
(323, 69, '_people_0_first_name', 'field_5af99594e81ba'),
(324, 69, 'people_0_last_name', 'Safar'),
(325, 69, '_people_0_last_name', 'field_5af995b2e81bb'),
(326, 69, 'people_0_position', 'Co-founder, CEO'),
(327, 69, '_people_0_position', 'field_5af995c2e81bc'),
(328, 69, 'people_1_avatar', '59'),
(329, 69, '_people_1_avatar', 'field_5af9957ee81b9'),
(330, 69, 'people_1_first_name', 'Itzik'),
(331, 69, '_people_1_first_name', 'field_5af99594e81ba'),
(332, 69, 'people_1_last_name', 'Spitzen'),
(333, 69, '_people_1_last_name', 'field_5af995b2e81bb'),
(334, 69, 'people_1_position', 'Co-founder, CTO'),
(335, 69, '_people_1_position', 'field_5af995c2e81bc'),
(336, 69, 'people_2_avatar', '60'),
(337, 69, '_people_2_avatar', 'field_5af9957ee81b9'),
(338, 69, 'people_2_first_name', 'Nadine'),
(339, 69, '_people_2_first_name', 'field_5af99594e81ba'),
(340, 69, 'people_2_last_name', 'Ezzie'),
(341, 69, '_people_2_last_name', 'field_5af995b2e81bb'),
(342, 69, 'people_2_position', 'Director of Customer Success'),
(343, 69, '_people_2_position', 'field_5af995c2e81bc'),
(344, 69, 'people', '3'),
(345, 69, '_people', 'field_5af99562e81b8'),
(346, 69, 'people_0_name_separator', ''),
(347, 69, '_people_0_name_separator', 'field_5af99685b6681'),
(348, 69, 'people_1_name_separator', ''),
(349, 69, '_people_1_name_separator', 'field_5af99685b6681'),
(350, 69, 'people_2_name_separator', '-'),
(351, 69, '_people_2_name_separator', 'field_5af99685b6681'),
(352, 70, '_menu_item_type', 'custom'),
(353, 70, '_menu_item_menu_item_parent', '0'),
(354, 70, '_menu_item_object_id', '70'),
(355, 70, '_menu_item_object', 'custom'),
(356, 70, '_menu_item_target', ''),
(357, 70, '_menu_item_classes', 'a:1:{i:0;s:11:"mobile-only";}'),
(358, 70, '_menu_item_xfn', ''),
(359, 70, '_menu_item_url', '/login'),
(361, 73, '_wp_attached_file', '2018/05/billboard-case-study.png'),
(362, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:627;s:4:"file";s:32:"2018/05/billboard-case-study.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"billboard-case-study-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:32:"billboard-case-study-300x157.png";s:5:"width";i:300;s:6:"height";i:157;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:32:"billboard-case-study-768x401.png";s:5:"width";i:768;s:6:"height";i:401;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:33:"billboard-case-study-1024x535.png";s:5:"width";i:1024;s:6:"height";i:535;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:32:"billboard-case-study-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:11:"cover_large";a:4:{s:4:"file";s:33:"billboard-case-study-1200x615.png";s:5:"width";i:1200;s:6:"height";i:615;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(363, 74, '_edit_last', '1'),
(364, 74, '_edit_lock', '1526491339:1'),
(365, 29, '_wp_old_slug', 'real-estate-software'),
(366, 39, 'case_study_logo', '29'),
(367, 39, '_case_study_logo', 'field_5af9c192d0d30'),
(368, 39, 'case_study_cover', '25'),
(369, 39, '_case_study_cover', 'field_5af9c1d9d0d31'),
(370, 31, '_wp_old_slug', 'yardi'),
(371, 38, 'case_study_logo', '31'),
(372, 38, '_case_study_logo', 'field_5af9c192d0d30'),
(373, 38, 'case_study_cover', '25'),
(374, 38, '_case_study_cover', 'field_5af9c1d9d0d31'),
(375, 26, '_wp_old_slug', 'casto'),
(376, 37, 'case_study_logo', '26'),
(377, 37, '_case_study_logo', 'field_5af9c192d0d30'),
(378, 37, 'case_study_cover', '25'),
(379, 37, '_case_study_cover', 'field_5af9c1d9d0d31'),
(380, 30, '_wp_old_slug', 'vts'),
(381, 36, 'case_study_logo', '30'),
(382, 36, '_case_study_logo', 'field_5af9c192d0d30'),
(383, 36, 'case_study_cover', '25'),
(384, 36, '_case_study_cover', 'field_5af9c1d9d0d31'),
(385, 28, '_wp_old_slug', 'nestio'),
(386, 35, 'case_study_logo', '28'),
(387, 35, '_case_study_logo', 'field_5af9c192d0d30'),
(388, 35, 'case_study_cover', '25'),
(389, 35, '_case_study_cover', 'field_5af9c1d9d0d31'),
(390, 27, '_wp_old_slug', 'entrata'),
(391, 34, 'case_study_logo', '27'),
(392, 34, '_case_study_logo', 'field_5af9c192d0d30'),
(393, 34, 'case_study_cover', '25'),
(394, 34, '_case_study_cover', 'field_5af9c1d9d0d31'),
(429, 87, '_edit_last', '1'),
(430, 87, '_edit_lock', '1526491734:1'),
(431, 87, '_wp_page_template', 'page-templates/page-case-studies.php'),
(432, 87, 'page_subheading', '<span style="color: #ffffff;">LeasePilot combines document automation, word processing |and user-centric interfaces into a single web-based platform, expressly designed to radically accelerate the entire process.</span>'),
(433, 87, '_page_subheading', 'field_5af83db84808e'),
(434, 87, 'background', 'image'),
(435, 87, '_background', 'field_5af83c494f983'),
(436, 87, 'background_image', '73'),
(437, 87, '_background_image', 'field_5af83ccd4f985'),
(438, 88, 'page_subheading', 'LeasePilot combines document automation, word processing |and user-centric interfaces into a single web-based platform, expressly designed to radically accelerate the entire process.'),
(439, 88, '_page_subheading', 'field_5af83db84808e'),
(440, 88, 'background', 'image'),
(441, 88, '_background', 'field_5af83c494f983'),
(442, 88, 'background_image', ''),
(443, 88, '_background_image', 'field_5af83ccd4f985'),
(444, 89, 'page_subheading', 'LeasePilot combines document automation, word processing |and user-centric interfaces into a single web-based platform, expressly designed to radically accelerate the entire process.'),
(445, 89, '_page_subheading', 'field_5af83db84808e'),
(446, 89, 'background', 'image'),
(447, 89, '_background', 'field_5af83c494f983'),
(448, 89, 'background_image', '73'),
(449, 89, '_background_image', 'field_5af83ccd4f985'),
(450, 90, '_menu_item_type', 'post_type'),
(451, 90, '_menu_item_menu_item_parent', '0'),
(452, 90, '_menu_item_object_id', '87'),
(453, 90, '_menu_item_object', 'page'),
(454, 90, '_menu_item_target', ''),
(455, 90, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(456, 90, '_menu_item_xfn', ''),
(457, 90, '_menu_item_url', ''),
(459, 91, '_edit_last', '1'),
(460, 91, '_edit_lock', '1526434308:1'),
(461, 91, '_wp_page_template', 'page-templates/page-resources.php'),
(462, 91, 'page_subheading', '<span style="color: #ffffff;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor ipsum nec neque condimentum, in rhoncus enim commodo.</span>'),
(463, 91, '_page_subheading', 'field_5af83db84808e'),
(464, 91, 'background', 'image'),
(465, 91, '_background', 'field_5af83c494f983'),
(466, 92, 'page_subheading', ''),
(467, 92, '_page_subheading', 'field_5af83db84808e'),
(468, 92, 'background', 'none'),
(469, 92, '_background', 'field_5af83c494f983'),
(470, 93, '_menu_item_type', 'post_type'),
(471, 93, '_menu_item_menu_item_parent', '0'),
(472, 93, '_menu_item_object_id', '91'),
(473, 93, '_menu_item_object', 'page'),
(474, 93, '_menu_item_target', ''),
(475, 93, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(476, 93, '_menu_item_xfn', ''),
(477, 93, '_menu_item_url', ''),
(479, 10, 'page_title_color', '#fc4513'),
(480, 10, '_page_title_color', 'field_5afa4a216bff6'),
(481, 95, 'page_subheading', '<span style="color: #3c4542;">LeasePilot’s management team blends deep legal insights with the technological vision.</span>'),
(482, 95, '_page_subheading', 'field_5af83db84808e'),
(483, 95, 'background', 'image'),
(484, 95, '_background', 'field_5af83c494f983'),
(485, 95, 'background_image', '56'),
(486, 95, '_background_image', 'field_5af83ccd4f985'),
(487, 95, 'people_0_avatar', '58'),
(488, 95, '_people_0_avatar', 'field_5af9957ee81b9'),
(489, 95, 'people_0_first_name', 'Gabriel'),
(490, 95, '_people_0_first_name', 'field_5af99594e81ba'),
(491, 95, 'people_0_last_name', 'Safar'),
(492, 95, '_people_0_last_name', 'field_5af995b2e81bb'),
(493, 95, 'people_0_position', 'Co-founder, CEO'),
(494, 95, '_people_0_position', 'field_5af995c2e81bc'),
(495, 95, 'people_1_avatar', '59'),
(496, 95, '_people_1_avatar', 'field_5af9957ee81b9'),
(497, 95, 'people_1_first_name', 'Itzik'),
(498, 95, '_people_1_first_name', 'field_5af99594e81ba'),
(499, 95, 'people_1_last_name', 'Spitzen'),
(500, 95, '_people_1_last_name', 'field_5af995b2e81bb'),
(501, 95, 'people_1_position', 'Co-founder, CTO'),
(502, 95, '_people_1_position', 'field_5af995c2e81bc'),
(503, 95, 'people_2_avatar', '60'),
(504, 95, '_people_2_avatar', 'field_5af9957ee81b9'),
(505, 95, 'people_2_first_name', 'Nadine'),
(506, 95, '_people_2_first_name', 'field_5af99594e81ba'),
(507, 95, 'people_2_last_name', 'Ezzie'),
(508, 95, '_people_2_last_name', 'field_5af995b2e81bb'),
(509, 95, 'people_2_position', 'Director of Customer Success'),
(510, 95, '_people_2_position', 'field_5af995c2e81bc'),
(511, 95, 'people', '3'),
(512, 95, '_people', 'field_5af99562e81b8'),
(513, 95, 'people_0_name_separator', ''),
(514, 95, '_people_0_name_separator', 'field_5af99685b6681'),
(515, 95, 'people_1_name_separator', ''),
(516, 95, '_people_1_name_separator', 'field_5af99685b6681'),
(517, 95, 'people_2_name_separator', '-'),
(518, 95, '_people_2_name_separator', 'field_5af99685b6681'),
(519, 95, 'page_title_color', '#fc4513'),
(520, 95, '_page_title_color', 'field_5afa4a216bff6'),
(521, 87, 'page_title_color', '#ffffff'),
(522, 87, '_page_title_color', 'field_5afa4a216bff6'),
(523, 96, 'page_subheading', '<span style="color: #ffffff;">LeasePilot combines document automation, word processing |and user-centric interfaces into a single web-based platform, expressly designed to radically accelerate the entire process.</span>'),
(524, 96, '_page_subheading', 'field_5af83db84808e'),
(525, 96, 'background', 'image'),
(526, 96, '_background', 'field_5af83c494f983'),
(527, 96, 'background_image', '73'),
(528, 96, '_background_image', 'field_5af83ccd4f985'),
(529, 96, 'page_title_color', '#ffffff'),
(530, 96, '_page_title_color', 'field_5afa4a216bff6'),
(531, 91, 'page_title_color', '#ffffff'),
(532, 91, '_page_title_color', 'field_5afa4a216bff6'),
(533, 92, 'page_title_color', '#fc4513'),
(534, 92, '_page_title_color', 'field_5afa4a216bff6'),
(535, 37, 'page_title_color', '#ffffff'),
(536, 37, '_page_title_color', 'field_5afa4a216bff6'),
(537, 37, 'page_subheading', '<span style="color: #ffffff;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor ipsum nec neque condimentum, in rhoncus enim commodo.</span>'),
(538, 37, '_page_subheading', 'field_5af83db84808e'),
(539, 37, 'background', 'image'),
(540, 37, '_background', 'field_5af83c494f983'),
(541, 37, 'background_image', '73'),
(542, 37, '_background_image', 'field_5af83ccd4f985'),
(543, 98, '_wp_attached_file', '2018/05/casto-singular.png'),
(544, 98, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:382;s:6:"height";i:126;s:4:"file";s:26:"2018/05/casto-singular.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"casto-singular-150x126.png";s:5:"width";i:150;s:6:"height";i:126;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"casto-singular-300x99.png";s:5:"width";i:300;s:6:"height";i:99;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(545, 37, 'case_study_logo_single', '98'),
(546, 37, '_case_study_logo_single', 'field_5afadc153c9e0'),
(547, 99, '_edit_last', '1'),
(548, 99, '_edit_lock', '1526491729:1'),
(555, 37, 'case_study_blocks_1_block_title', 'Overview'),
(556, 37, '_case_study_blocks_1_block_title', 'field_5afaf1eb2cc8b'),
(557, 37, 'case_study_blocks_1_block_content', 'Based in Columbus, Ohio, CASTO is a privately held real estate development and management company that’s been in business since 1926. The company develops, owns and manages approximately 23 million square feet across more than 100 shopping centers in seven states.\r\n\r\nLed by Director C.H. Waterman, CASTO’s lean legal team keeps busy managing all legal matters for the company. “Our group has five attorneys in Columbus, two paralegals and an administrative assistant, plus a part-time attorney and two paralegals that work out of our Sarasota, Florida office,” said Waterman. “We handle all tasks related to litigation, HR issues, risk management and leasing of all commercial shopping centers.”\r\n<p class="mb0">According to Waterman, leasing is the lifeblood of the company. To that end, a portion of the legal staff is dedicated exclusively to the leasing business. “Those team members are essential to the corporate function and the overall health of our company,” he said. “We’re responsible for drafting and negotiating the leases, and for keeping tenants happy.”</p>'),
(558, 37, '_case_study_blocks_1_block_content', 'field_5afaf2062cc8c'),
(559, 37, 'case_study_blocks_1_block_quote', ''),
(560, 37, '_case_study_blocks_1_block_quote', 'field_5afaf2252cc8d'),
(561, 37, 'case_study_blocks_1_block_background_color', '#f6f5f5'),
(562, 37, '_case_study_blocks_1_block_background_color', 'field_5afaf1902cc8a'),
(563, 37, 'case_study_blocks', 'a:6:{i:0;s:17:"big_heading_block";i:1;s:16:"text_quote_block";i:2;s:16:"text_quote_block";i:3;s:9:"cta_block";i:4;s:16:"text_quote_block";i:5;s:16:"text_quote_block";}'),
(564, 37, '_case_study_blocks', 'field_5afaf0ea2cc83'),
(565, 37, 'case_study_blocks_2_block_title', 'Challenge'),
(566, 37, '_case_study_blocks_2_block_title', 'field_5afaf1eb2cc8b'),
(567, 37, 'case_study_blocks_2_block_quote', '“We needed a tool designed specifically to handle legal documents, with an intuitive interface that would be easy for new users to learn quickly, when I learned about LeasePilot at a conference, I realized it was exactly the solution we needed.”'),
(568, 37, '_case_study_blocks_2_block_quote', 'field_5afaf2252cc8d'),
(569, 37, 'case_study_blocks_2_block_content', 'Waterman’s team faces numerous challenges every day, not the least of which is responding to the intense pressure to complete leases quickly. There is also intense pressure from throughout the company to move from a letter of intent (LOI) to a signed lease as quickly as possible.“\r\n\r\nFor every day we don’t have a signed lease, we lose income for that space,” Waterman said. However, quality is also critical. “You can’t sacrifice the quality of the work, the value of the lease and the legal protections it provides for both parties, just to complete the transaction quickly. There’s a constant need for balance between quality of work and the velocity at which the lease travels through the department,” he said.\r\n\r\nIn an attempt to achieve this balance, CASTO implemented a few different initiatives: developing 20 different lease forms, developing a robust language library, and assigning lease drafting to an administrative assistant. However, each of these initiatives resulted in even more challenges: updating 20 different forms multiple times a year;\r\nmanually searching, inserting, and formatting correct language from the library; and intensively reviewing lease drafts.\r\n<p class="mb0">Additionally, the amount of time it was taking to get leases done in-house created bottlenecks and at times, these bottlenecks forced them to rely on outside counsel. “We tried using outside counsel to handle some of the overflow, but doing so meant losing some control over the quality of work,” said Waterman. “It was also costly.”</p>'),
(570, 37, '_case_study_blocks_2_block_content', 'field_5afaf2062cc8c'),
(571, 37, 'case_study_blocks_2_block_background_color', '#ffffff'),
(572, 37, '_case_study_blocks_2_block_background_color', 'field_5afaf1902cc8a'),
(601, 115, '_wp_attached_file', '2018/05/cta-img.png'),
(602, 115, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:246;s:6:"height";i:319;s:4:"file";s:19:"2018/05/cta-img.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"cta-img-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"cta-img-231x300.png";s:5:"width";i:231;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:19:"cta-img-246x205.png";s:5:"width";i:246;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(655, 37, 'case_study_blocks_0_big_heading', 'CASTO accelerates leasing process and cuts costs with LeasePilot.'),
(656, 37, '_case_study_blocks_0_big_heading', 'field_5afaf1262cc84'),
(657, 37, 'case_study_blocks_0_text_color', '#fc4513'),
(658, 37, '_case_study_blocks_0_text_color', 'field_5afaf1492cc85'),
(659, 37, 'case_study_blocks_0_block_background_color', '#ffffff'),
(660, 37, '_case_study_blocks_0_block_background_color', 'field_5afaf1652cc86'),
(661, 37, 'case_study_blocks_3_cta_image', '115'),
(662, 37, '_case_study_blocks_3_cta_image', 'field_5afafa71e55a6'),
(663, 37, 'case_study_blocks_3_cta_title', 'Reading is'),
(664, 37, '_case_study_blocks_3_cta_title', 'field_5afaf4e378118'),
(665, 37, 'case_study_blocks_3_cta_subtitle', 'believing:'),
(666, 37, '_case_study_blocks_3_cta_subtitle', 'field_5afaf4ee78119'),
(667, 37, 'case_study_blocks_3_cta_button_title', 'Download eBook »'),
(668, 37, '_case_study_blocks_3_cta_button_title', 'field_5afaf5107811a'),
(669, 37, 'case_study_blocks_3_cta_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet hendrerit libero.'),
(670, 37, '_case_study_blocks_3_cta_description', 'field_5afaf66c7ce55'),
(671, 37, 'case_study_blocks_3_cta_button_link', 'https://delindesign.com'),
(672, 37, '_case_study_blocks_3_cta_button_link', 'field_5afaf5217811b'),
(673, 37, 'case_study_blocks_3_block_background_color', '#3c4542'),
(674, 37, '_case_study_blocks_3_block_background_color', 'field_5afaf3fa78117'),
(675, 37, 'case_study_blocks_4_block_title', 'Solution'),
(676, 37, '_case_study_blocks_4_block_title', 'field_5afaf1eb2cc8b'),
(677, 37, 'case_study_blocks_4_block_quote', ''),
(678, 37, '_case_study_blocks_4_block_quote', 'field_5afaf2252cc8d'),
(679, 37, 'case_study_blocks_4_block_content', 'LeasePilot offers a web-based lease automation platform for real estate companies to streamline the process of drafting, editing and ultimately closing leases, all while reducing costs. The platform enables real estate companies to use their own lease forms and language, and its intuitive interface enables users to get up and running quickly with minimal training. LeasePilot also empowers staff without legal expertise to take a more active role in lease drafting and editing, without the additional legal oversight and review typically required.\r\n<p class="mb0">Waterman said integrating the team’s existing lease forms and language with the LeasePilot platform was smooth, fast and easy. “We didn’t experience any significant downtime in the leasing process,” he said. “The typical hiccups of installing new software didn’t happen—it was simple to integrate and easy to use from the start.”</p>'),
(680, 37, '_case_study_blocks_4_block_content', 'field_5afaf2062cc8c'),
(681, 37, 'case_study_blocks_4_block_background_color', '#f6f5f5'),
(682, 37, '_case_study_blocks_4_block_background_color', 'field_5afaf1902cc8a'),
(683, 37, 'case_study_blocks_5_block_title', 'Challenge'),
(684, 37, '_case_study_blocks_5_block_title', 'field_5afaf1eb2cc8b'),
(685, 37, 'case_study_blocks_5_block_quote', '“LeasePilot has significantly cut down the time it takes us to prepare first drafts of leases – down to less than 30 minutes for simple deals. That has also reduced the time it takes us to get leases into our tenants’ hands – in some cases we’re now able to send a lease to a tenant within a day of receiving  the LOI.”'),
(686, 37, '_case_study_blocks_5_block_quote', 'field_5afaf2252cc8d'),
(687, 37, 'case_study_blocks_5_block_content', 'Since implementing LeasePilot, CASTO’s legal team has reduced the amount of time spent on the leasing process while also getting lease drafts to tenants quicker. In particular, “LeasePilot has significantly cut down the time it takes us to prepare first drafts of leases – down to less than 30 minutes for simple deals. That has also reduced the time it takes us to get leases into our tenants’ hands – in some cases we’re now able to send a lease to a tenant within a day of receiving the LOI,” said Waterman.\r\n\r\nReducing the amount of time spent on the leasing process has had multiple benefits for CASTO. To start, it has allowed the legal team to reduce bottlenecks by spending more time on high-value work. According to Waterman, “LeasePilot frees up our time to focus on higher-level tasks, such as legal analysis, which can’t be outsourced.” LeasePilot has also enabled CASTO to cut their outside law firm bills. “Leases can now be processed by administrative-level employees, cutting hours off lease-prep time we used to outsource,” said Waterman.\r\n<p class="mb0">In addition, there are potential revenue implications since speeding up the process of going from LOI to signed lease can lead to additional revenue. “Every day sooner we can get a lease signed means another day of rent received,” said Waterman. Finally, Waterman said LeasePilot is helping the legal department make a measurable impact on the company’s bottom line. “Legal departments are usually viewed as ‘cost centers,’ and other departments want to see you reducing costs,” he said. “LeasePilot helps us show how we’re working to reduce costs and increase revenue for the company.”</p>'),
(688, 37, '_case_study_blocks_5_block_content', 'field_5afaf2062cc8c'),
(689, 37, 'case_study_blocks_5_block_background_color', '#ffffff'),
(690, 37, '_case_study_blocks_5_block_background_color', 'field_5afaf1902cc8a'),
(691, 39, 'page_title_color', '#fc4513'),
(692, 39, '_page_title_color', 'field_5afa4a216bff6'),
(693, 39, 'page_subheading', ''),
(694, 39, '_page_subheading', 'field_5af83db84808e'),
(695, 39, 'background', 'none'),
(696, 39, '_background', 'field_5af83c494f983'),
(697, 39, 'case_study_logo_single', '29'),
(698, 39, '_case_study_logo_single', 'field_5afadc153c9e0'),
(699, 39, 'case_study_blocks', ''),
(700, 39, '_case_study_blocks', 'field_5afaf0ea2cc83'),
(701, 116, '_edit_last', '1'),
(702, 116, '_edit_lock', '1526411034:1'),
(703, 117, '_edit_last', '1'),
(704, 117, '_edit_lock', '1526411056:1'),
(705, 118, '_edit_last', '1'),
(706, 118, '_edit_lock', '1526411063:1'),
(707, 119, '_edit_last', '1'),
(708, 119, '_edit_lock', '1526411078:1'),
(709, 120, '_edit_last', '1'),
(710, 120, '_edit_lock', '1526411085:1'),
(711, 121, '_edit_last', '1'),
(712, 121, '_edit_lock', '1526411100:1'),
(713, 122, '_edit_last', '1'),
(714, 122, '_edit_lock', '1526411153:1'),
(715, 123, '_edit_last', '1'),
(716, 123, '_edit_lock', '1526475938:1'),
(717, 124, '_wp_attached_file', '2018/05/billboard-resource.png'),
(718, 124, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:627;s:4:"file";s:30:"2018/05/billboard-resource.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"billboard-resource-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:30:"billboard-resource-300x157.png";s:5:"width";i:300;s:6:"height";i:157;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:30:"billboard-resource-768x401.png";s:5:"width";i:768;s:6:"height";i:401;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:31:"billboard-resource-1024x535.png";s:5:"width";i:1024;s:6:"height";i:535;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:30:"billboard-resource-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:11:"cover_large";a:4:{s:4:"file";s:31:"billboard-resource-1200x615.png";s:5:"width";i:1200;s:6:"height";i:615;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(719, 91, 'background_image', '124'),
(720, 91, '_background_image', 'field_5af83ccd4f985'),
(721, 125, 'page_subheading', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor ipsum nec neque condimentum, in rhoncus enim commodo.'),
(722, 125, '_page_subheading', 'field_5af83db84808e'),
(723, 125, 'background', 'image'),
(724, 125, '_background', 'field_5af83c494f983'),
(725, 125, 'page_title_color', '#fc4513'),
(726, 125, '_page_title_color', 'field_5afa4a216bff6'),
(727, 125, 'background_image', '124'),
(728, 125, '_background_image', 'field_5af83ccd4f985'),
(729, 126, 'page_subheading', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor ipsum nec neque condimentum, in rhoncus enim commodo.'),
(730, 126, '_page_subheading', 'field_5af83db84808e'),
(731, 126, 'background', 'image'),
(732, 126, '_background', 'field_5af83c494f983'),
(733, 126, 'page_title_color', '#ffffff'),
(734, 126, '_page_title_color', 'field_5afa4a216bff6'),
(735, 126, 'background_image', '124'),
(736, 126, '_background_image', 'field_5af83ccd4f985'),
(737, 127, 'page_subheading', '<span style="color: #ffffff;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor ipsum nec neque condimentum, in rhoncus enim commodo.</span>'),
(738, 127, '_page_subheading', 'field_5af83db84808e'),
(739, 127, 'background', 'image'),
(740, 127, '_background', 'field_5af83c494f983'),
(741, 127, 'page_title_color', '#ffffff'),
(742, 127, '_page_title_color', 'field_5afa4a216bff6'),
(743, 127, 'background_image', '124'),
(744, 127, '_background_image', 'field_5af83ccd4f985'),
(745, 128, 'page_subheading', '<span style="color: #ffffff;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor ipsum nec neque condimentum, in rhoncus enim commodo.</span>'),
(746, 128, '_page_subheading', 'field_5af83db84808e'),
(747, 128, 'background', 'image'),
(748, 128, '_background', 'field_5af83c494f983'),
(749, 128, 'page_title_color', '#ffffff'),
(750, 128, '_page_title_color', 'field_5afa4a216bff6'),
(751, 128, 'background_image', '124'),
(752, 128, '_background_image', 'field_5af83ccd4f985'),
(753, 129, 'page_subheading', '<span style="color: #ffffff;">LeasePilot combines document automation, word processing |and user-centric interfaces into a single web-based platform, expressly designed to radically accelerate the entire process.</span>'),
(754, 129, '_page_subheading', 'field_5af83db84808e'),
(755, 129, 'background', 'image'),
(756, 129, '_background', 'field_5af83c494f983'),
(757, 129, 'background_image', '73'),
(758, 129, '_background_image', 'field_5af83ccd4f985'),
(759, 129, 'page_title_color', '#ffffff'),
(760, 129, '_page_title_color', 'field_5afa4a216bff6'),
(761, 132, '_edit_last', '1'),
(762, 132, '_edit_lock', '1526411720:1'),
(763, 134, '_wp_attached_file', '2018/05/resource-case-study.png'),
(764, 134, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:475;s:6:"height";i:400;s:4:"file";s:31:"2018/05/resource-case-study.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"resource-case-study-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:31:"resource-case-study-300x253.png";s:5:"width";i:300;s:6:"height";i:253;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:31:"resource-case-study-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(765, 135, '_wp_attached_file', '2018/05/resource-ebook.png');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(766, 135, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:340;s:6:"height";i:435;s:4:"file";s:26:"2018/05/resource-ebook.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"resource-ebook-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"resource-ebook-234x300.png";s:5:"width";i:234;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:26:"resource-ebook-340x205.png";s:5:"width";i:340;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(767, 136, '_wp_attached_file', '2018/05/resource-teer-sheet.png'),
(768, 136, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:455;s:6:"height";i:400;s:4:"file";s:31:"2018/05/resource-teer-sheet.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"resource-teer-sheet-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:31:"resource-teer-sheet-300x264.png";s:5:"width";i:300;s:6:"height";i:264;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:31:"resource-teer-sheet-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(769, 137, '_edit_last', '1'),
(770, 137, '_edit_lock', '1526428162:1'),
(771, 139, '_wp_attached_file', '2018/05/LeasePilot_PPT_Temp.pptx'),
(772, 123, 'download_file', '139'),
(773, 123, '_download_file', 'field_5afb7255bce6e'),
(774, 140, 'page_subheading', '<span style="color: #3c4542;">LeasePilot’s management team blends deep legal insights with the technological vision.</span>'),
(775, 140, '_page_subheading', 'field_5af83db84808e'),
(776, 140, 'background', 'image'),
(777, 140, '_background', 'field_5af83c494f983'),
(778, 140, 'background_image', '56'),
(779, 140, '_background_image', 'field_5af83ccd4f985'),
(780, 140, 'people_0_avatar', '58'),
(781, 140, '_people_0_avatar', 'field_5af9957ee81b9'),
(782, 140, 'people_0_first_name', 'Gabriel'),
(783, 140, '_people_0_first_name', 'field_5af99594e81ba'),
(784, 140, 'people_0_last_name', 'Safar'),
(785, 140, '_people_0_last_name', 'field_5af995b2e81bb'),
(786, 140, 'people_0_position', 'Co-founder, CEO'),
(787, 140, '_people_0_position', 'field_5af995c2e81bc'),
(788, 140, 'people_1_avatar', '59'),
(789, 140, '_people_1_avatar', 'field_5af9957ee81b9'),
(790, 140, 'people_1_first_name', 'Itzik'),
(791, 140, '_people_1_first_name', 'field_5af99594e81ba'),
(792, 140, 'people_1_last_name', 'Spitzen'),
(793, 140, '_people_1_last_name', 'field_5af995b2e81bb'),
(794, 140, 'people_1_position', 'Co-founder, CTO'),
(795, 140, '_people_1_position', 'field_5af995c2e81bc'),
(796, 140, 'people_2_avatar', '60'),
(797, 140, '_people_2_avatar', 'field_5af9957ee81b9'),
(798, 140, 'people_2_first_name', 'Nadine'),
(799, 140, '_people_2_first_name', 'field_5af99594e81ba'),
(800, 140, 'people_2_last_name', 'Ezzie'),
(801, 140, '_people_2_last_name', 'field_5af995b2e81bb'),
(802, 140, 'people_2_position', 'Director of Customer Success'),
(803, 140, '_people_2_position', 'field_5af995c2e81bc'),
(804, 140, 'people', '3'),
(805, 140, '_people', 'field_5af99562e81b8'),
(806, 140, 'people_0_name_separator', ''),
(807, 140, '_people_0_name_separator', 'field_5af99685b6681'),
(808, 140, 'people_1_name_separator', ''),
(809, 140, '_people_1_name_separator', 'field_5af99685b6681'),
(810, 140, 'people_2_name_separator', '-'),
(811, 140, '_people_2_name_separator', 'field_5af99685b6681'),
(812, 140, 'page_title_color', '#fc4513'),
(813, 140, '_page_title_color', 'field_5afa4a216bff6'),
(814, 141, 'page_subheading', '<span style="color: #3c4542;">LeasePilot’s management team blends deep legal insights with the technological vision.</span>'),
(815, 141, '_page_subheading', 'field_5af83db84808e'),
(816, 141, 'background', 'image'),
(817, 141, '_background', 'field_5af83c494f983'),
(818, 141, 'background_image', '56'),
(819, 141, '_background_image', 'field_5af83ccd4f985'),
(820, 141, 'people_0_avatar', '58'),
(821, 141, '_people_0_avatar', 'field_5af9957ee81b9'),
(822, 141, 'people_0_first_name', 'Gabriel'),
(823, 141, '_people_0_first_name', 'field_5af99594e81ba'),
(824, 141, 'people_0_last_name', 'Safar'),
(825, 141, '_people_0_last_name', 'field_5af995b2e81bb'),
(826, 141, 'people_0_position', 'Co-founder, CEO'),
(827, 141, '_people_0_position', 'field_5af995c2e81bc'),
(828, 141, 'people_1_avatar', '59'),
(829, 141, '_people_1_avatar', 'field_5af9957ee81b9'),
(830, 141, 'people_1_first_name', 'Itzik'),
(831, 141, '_people_1_first_name', 'field_5af99594e81ba'),
(832, 141, 'people_1_last_name', 'Spitzen'),
(833, 141, '_people_1_last_name', 'field_5af995b2e81bb'),
(834, 141, 'people_1_position', 'Co-founder, CTO'),
(835, 141, '_people_1_position', 'field_5af995c2e81bc'),
(836, 141, 'people_2_avatar', '60'),
(837, 141, '_people_2_avatar', 'field_5af9957ee81b9'),
(838, 141, 'people_2_first_name', 'Nadine'),
(839, 141, '_people_2_first_name', 'field_5af99594e81ba'),
(840, 141, 'people_2_last_name', 'Ezzie'),
(841, 141, '_people_2_last_name', 'field_5af995b2e81bb'),
(842, 141, 'people_2_position', 'Director of Customer Success'),
(843, 141, '_people_2_position', 'field_5af995c2e81bc'),
(844, 141, 'people', '3'),
(845, 141, '_people', 'field_5af99562e81b8'),
(846, 141, 'people_0_name_separator', ''),
(847, 141, '_people_0_name_separator', 'field_5af99685b6681'),
(848, 141, 'people_1_name_separator', ''),
(849, 141, '_people_1_name_separator', 'field_5af99685b6681'),
(850, 141, 'people_2_name_separator', '-'),
(851, 141, '_people_2_name_separator', 'field_5af99685b6681'),
(852, 141, 'page_title_color', '#fc4513'),
(853, 141, '_page_title_color', 'field_5afa4a216bff6'),
(854, 142, 'page_subheading', '<span style="color: #3c4542;">LeasePilot’s management team blends deep legal insights with the technological vision.</span>'),
(855, 142, '_page_subheading', 'field_5af83db84808e'),
(856, 142, 'background', 'image'),
(857, 142, '_background', 'field_5af83c494f983'),
(858, 142, 'background_image', '56'),
(859, 142, '_background_image', 'field_5af83ccd4f985'),
(860, 142, 'people_0_avatar', '58'),
(861, 142, '_people_0_avatar', 'field_5af9957ee81b9'),
(862, 142, 'people_0_first_name', 'Gabriel'),
(863, 142, '_people_0_first_name', 'field_5af99594e81ba'),
(864, 142, 'people_0_last_name', 'Safar'),
(865, 142, '_people_0_last_name', 'field_5af995b2e81bb'),
(866, 142, 'people_0_position', 'Co-founder, CEO'),
(867, 142, '_people_0_position', 'field_5af995c2e81bc'),
(868, 142, 'people_1_avatar', '59'),
(869, 142, '_people_1_avatar', 'field_5af9957ee81b9'),
(870, 142, 'people_1_first_name', 'Itzik'),
(871, 142, '_people_1_first_name', 'field_5af99594e81ba'),
(872, 142, 'people_1_last_name', 'Spitzen'),
(873, 142, '_people_1_last_name', 'field_5af995b2e81bb'),
(874, 142, 'people_1_position', 'Co-founder, CTO'),
(875, 142, '_people_1_position', 'field_5af995c2e81bc'),
(876, 142, 'people_2_avatar', '60'),
(877, 142, '_people_2_avatar', 'field_5af9957ee81b9'),
(878, 142, 'people_2_first_name', 'Nadine'),
(879, 142, '_people_2_first_name', 'field_5af99594e81ba'),
(880, 142, 'people_2_last_name', 'Ezzie'),
(881, 142, '_people_2_last_name', 'field_5af995b2e81bb'),
(882, 142, 'people_2_position', 'Director of Customer Success'),
(883, 142, '_people_2_position', 'field_5af995c2e81bc'),
(884, 142, 'people', '3'),
(885, 142, '_people', 'field_5af99562e81b8'),
(886, 142, 'people_0_name_separator', ''),
(887, 142, '_people_0_name_separator', 'field_5af99685b6681'),
(888, 142, 'people_1_name_separator', ''),
(889, 142, '_people_1_name_separator', 'field_5af99685b6681'),
(890, 142, 'people_2_name_separator', '-'),
(891, 142, '_people_2_name_separator', 'field_5af99685b6681'),
(892, 142, 'page_title_color', '#fc4513'),
(893, 142, '_page_title_color', 'field_5afa4a216bff6'),
(894, 143, 'page_subheading', '<span style="color: #3c4542;">LeasePilot’s management team blends deep legal insights with the technological vision.</span>'),
(895, 143, '_page_subheading', 'field_5af83db84808e'),
(896, 143, 'background', 'image'),
(897, 143, '_background', 'field_5af83c494f983'),
(898, 143, 'background_image', '56'),
(899, 143, '_background_image', 'field_5af83ccd4f985'),
(900, 143, 'people_0_avatar', '58'),
(901, 143, '_people_0_avatar', 'field_5af9957ee81b9'),
(902, 143, 'people_0_first_name', 'Gabriel'),
(903, 143, '_people_0_first_name', 'field_5af99594e81ba'),
(904, 143, 'people_0_last_name', 'Safar'),
(905, 143, '_people_0_last_name', 'field_5af995b2e81bb'),
(906, 143, 'people_0_position', 'Co-founder, CEO'),
(907, 143, '_people_0_position', 'field_5af995c2e81bc'),
(908, 143, 'people_1_avatar', '59'),
(909, 143, '_people_1_avatar', 'field_5af9957ee81b9'),
(910, 143, 'people_1_first_name', 'Itzik'),
(911, 143, '_people_1_first_name', 'field_5af99594e81ba'),
(912, 143, 'people_1_last_name', 'Spitzen'),
(913, 143, '_people_1_last_name', 'field_5af995b2e81bb'),
(914, 143, 'people_1_position', 'Co-founder, CTO'),
(915, 143, '_people_1_position', 'field_5af995c2e81bc'),
(916, 143, 'people_2_avatar', '60'),
(917, 143, '_people_2_avatar', 'field_5af9957ee81b9'),
(918, 143, 'people_2_first_name', 'Nadine'),
(919, 143, '_people_2_first_name', 'field_5af99594e81ba'),
(920, 143, 'people_2_last_name', 'Ezzie'),
(921, 143, '_people_2_last_name', 'field_5af995b2e81bb'),
(922, 143, 'people_2_position', 'Director of Customer Success'),
(923, 143, '_people_2_position', 'field_5af995c2e81bc'),
(924, 143, 'people', '3'),
(925, 143, '_people', 'field_5af99562e81b8'),
(926, 143, 'people_0_name_separator', ''),
(927, 143, '_people_0_name_separator', 'field_5af99685b6681'),
(928, 143, 'people_1_name_separator', ''),
(929, 143, '_people_1_name_separator', 'field_5af99685b6681'),
(930, 143, 'people_2_name_separator', '-'),
(931, 143, '_people_2_name_separator', 'field_5af99685b6681'),
(932, 143, 'page_title_color', '#fc4513'),
(933, 143, '_page_title_color', 'field_5afa4a216bff6'),
(934, 144, '_edit_last', '1'),
(935, 144, '_wp_page_template', 'default'),
(936, 144, 'page_title_color', '#fc4513'),
(937, 144, '_page_title_color', 'field_5afa4a216bff6'),
(938, 144, 'page_subheading', ''),
(939, 144, '_page_subheading', 'field_5af83db84808e'),
(940, 144, 'background', 'none'),
(941, 144, '_background', 'field_5af83c494f983'),
(942, 145, 'page_title_color', '#fc4513'),
(943, 145, '_page_title_color', 'field_5afa4a216bff6'),
(944, 145, 'page_subheading', ''),
(945, 145, '_page_subheading', 'field_5af83db84808e'),
(946, 145, 'background', 'none'),
(947, 145, '_background', 'field_5af83c494f983'),
(948, 144, '_edit_lock', '1526477768:1'),
(949, 5, 'page_title_color', '#3c4542'),
(950, 5, '_page_title_color', 'field_5afa4a216bff6'),
(951, 5, 'page_subheading', '<h1 class="secondary-color">Rethinking the commercial <span class="ff-hn lighter">real estate lease</span><span class="primary-color big-dot">.</span></h1>\r\n<a class="button button__cta button__cta--dark" href="/#!">See what’s possible »</a>'),
(952, 5, '_page_subheading', 'field_5af83db84808e'),
(953, 5, 'background', 'video'),
(954, 5, '_background', 'field_5af83c494f983'),
(955, 5, 'background_video', '150'),
(956, 5, '_background_video', 'field_5af83cef4f986'),
(957, 146, 'page_title_color', '#fc4513'),
(958, 146, '_page_title_color', 'field_5afa4a216bff6'),
(959, 146, 'page_subheading', ''),
(960, 146, '_page_subheading', 'field_5af83db84808e'),
(961, 146, 'background', 'video'),
(962, 146, '_background', 'field_5af83c494f983'),
(963, 146, 'background_video', 'https://vimeo.com/268790894'),
(964, 146, '_background_video', 'field_5af83cef4f986'),
(965, 5, 'background_color', '#fc4513'),
(966, 5, '_background_color', 'field_5af83ca54f984'),
(967, 147, 'page_title_color', '#fc4513'),
(968, 147, '_page_title_color', 'field_5afa4a216bff6'),
(969, 147, 'page_subheading', ''),
(970, 147, '_page_subheading', 'field_5af83db84808e'),
(971, 147, 'background', 'color'),
(972, 147, '_background', 'field_5af83c494f983'),
(973, 147, 'background_video', 'https://vimeo.com/268790894'),
(974, 147, '_background_video', 'field_5af83cef4f986'),
(975, 147, 'background_color', '#fc4513'),
(976, 147, '_background_color', 'field_5af83ca54f984'),
(977, 148, 'page_title_color', '#3c4542'),
(978, 148, '_page_title_color', 'field_5afa4a216bff6'),
(979, 148, 'page_subheading', ''),
(980, 148, '_page_subheading', 'field_5af83db84808e'),
(981, 148, 'background', 'color'),
(982, 148, '_background', 'field_5af83c494f983'),
(983, 148, 'background_video', 'https://vimeo.com/268790894'),
(984, 148, '_background_video', 'field_5af83cef4f986'),
(985, 148, 'background_color', '#fc4513'),
(986, 148, '_background_color', 'field_5af83ca54f984'),
(987, 149, 'page_title_color', '#3c4542'),
(988, 149, '_page_title_color', 'field_5afa4a216bff6'),
(989, 149, 'page_subheading', ''),
(990, 149, '_page_subheading', 'field_5af83db84808e'),
(991, 149, 'background', 'video'),
(992, 149, '_background', 'field_5af83c494f983'),
(993, 149, 'background_video', 'https://vimeo.com/268790894'),
(994, 149, '_background_video', 'field_5af83cef4f986'),
(995, 149, 'background_color', '#fc4513'),
(996, 149, '_background_color', 'field_5af83ca54f984'),
(997, 150, '_wp_attached_file', '2018/05/LEA2463_RebrandAssets_Animation_R1_NoLogo.mp4'),
(998, 150, '_wp_attachment_metadata', 'a:10:{s:7:"bitrate";i:7953564;s:8:"filesize";i:8711595;s:9:"mime_type";s:15:"video/quicktime";s:6:"length";i:9;s:16:"length_formatted";s:4:"0:09";s:5:"width";i:1920;s:6:"height";i:1080;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:17:"created_timestamp";i:1522681021;}'),
(999, 151, '_wp_attached_file', '2018/05/compare.png'),
(1000, 151, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:798;s:4:"file";s:19:"2018/05/compare.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"compare-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"compare-300x200.png";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:19:"compare-768x511.png";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:20:"compare-1024x681.png";s:5:"width";i:1024;s:6:"height";i:681;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:19:"compare-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:11:"cover_large";a:4:{s:4:"file";s:20:"compare-1200x615.png";s:5:"width";i:1200;s:6:"height";i:615;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1001, 152, '_wp_attached_file', '2018/05/computer.png'),
(1002, 152, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:546;s:6:"height";i:371;s:4:"file";s:20:"2018/05/computer.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"computer-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:20:"computer-300x204.png";s:5:"width";i:300;s:6:"height";i:204;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:20:"computer-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1003, 153, '_wp_attached_file', '2018/05/entrata-w.png'),
(1004, 153, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:616;s:6:"height";i:118;s:4:"file";s:21:"2018/05/entrata-w.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"entrata-w-150x118.png";s:5:"width";i:150;s:6:"height";i:118;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:20:"entrata-w-300x57.png";s:5:"width";i:300;s:6:"height";i:57;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:21:"entrata-w-400x118.png";s:5:"width";i:400;s:6:"height";i:118;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1005, 154, '_wp_attached_file', '2018/05/nestio-w.png'),
(1006, 154, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:700;s:6:"height";i:141;s:4:"file";s:20:"2018/05/nestio-w.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"nestio-w-150x141.png";s:5:"width";i:150;s:6:"height";i:141;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"nestio-w-300x60.png";s:5:"width";i:300;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:20:"nestio-w-400x141.png";s:5:"width";i:400;s:6:"height";i:141;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1007, 155, '_wp_attached_file', '2018/05/real-estate-software-w.png'),
(1008, 155, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:424;s:6:"height";i:224;s:4:"file";s:34:"2018/05/real-estate-software-w.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"real-estate-software-w-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:34:"real-estate-software-w-300x158.png";s:5:"width";i:300;s:6:"height";i:158;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:34:"real-estate-software-w-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1009, 156, '_wp_attached_file', '2018/05/screenshot_11.png'),
(1010, 156, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:324;s:6:"height";i:183;s:4:"file";s:25:"2018/05/screenshot_11.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"screenshot_11-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"screenshot_11-300x169.png";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1011, 157, '_wp_attached_file', '2018/05/tailored.png'),
(1012, 157, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:718;s:4:"file";s:20:"2018/05/tailored.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"tailored-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:20:"tailored-300x180.png";s:5:"width";i:300;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:20:"tailored-768x460.png";s:5:"width";i:768;s:6:"height";i:460;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:21:"tailored-1024x613.png";s:5:"width";i:1024;s:6:"height";i:613;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:20:"tailored-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:11:"cover_large";a:4:{s:4:"file";s:21:"tailored-1200x615.png";s:5:"width";i:1200;s:6:"height";i:615;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1013, 158, '_wp_attached_file', '2018/05/transform.png'),
(1014, 158, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:736;s:4:"file";s:21:"2018/05/transform.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"transform-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"transform-300x184.png";s:5:"width";i:300;s:6:"height";i:184;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:21:"transform-768x471.png";s:5:"width";i:768;s:6:"height";i:471;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:22:"transform-1024x628.png";s:5:"width";i:1024;s:6:"height";i:628;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:21:"transform-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:11:"cover_large";a:4:{s:4:"file";s:22:"transform-1200x615.png";s:5:"width";i:1200;s:6:"height";i:615;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1015, 159, '_wp_attached_file', '2018/05/turbocharge.png'),
(1016, 159, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:724;s:4:"file";s:23:"2018/05/turbocharge.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"turbocharge-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"turbocharge-300x181.png";s:5:"width";i:300;s:6:"height";i:181;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:23:"turbocharge-768x463.png";s:5:"width";i:768;s:6:"height";i:463;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:24:"turbocharge-1024x618.png";s:5:"width";i:1024;s:6:"height";i:618;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:23:"turbocharge-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:11:"cover_large";a:4:{s:4:"file";s:24:"turbocharge-1200x615.png";s:5:"width";i:1200;s:6:"height";i:615;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1017, 160, '_wp_attached_file', '2018/05/vts-w.png'),
(1018, 160, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:344;s:6:"height";i:356;s:4:"file";s:17:"2018/05/vts-w.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"vts-w-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"vts-w-290x300.png";s:5:"width";i:290;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:17:"vts-w-344x205.png";s:5:"width";i:344;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1019, 161, '_wp_attached_file', '2018/05/yardi-w.png'),
(1020, 161, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:628;s:6:"height";i:154;s:4:"file";s:19:"2018/05/yardi-w.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"yardi-w-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"yardi-w-300x74.png";s:5:"width";i:300;s:6:"height";i:74;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:19:"yardi-w-400x154.png";s:5:"width";i:400;s:6:"height";i:154;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1021, 162, 'page_title_color', '#3c4542'),
(1022, 162, '_page_title_color', 'field_5afa4a216bff6'),
(1023, 162, 'page_subheading', ''),
(1024, 162, '_page_subheading', 'field_5af83db84808e'),
(1025, 162, 'background', 'video'),
(1026, 162, '_background', 'field_5af83c494f983'),
(1027, 162, 'background_video', '150'),
(1028, 162, '_background_video', 'field_5af83cef4f986'),
(1029, 162, 'background_color', '#fc4513'),
(1030, 162, '_background_color', 'field_5af83ca54f984'),
(1031, 163, 'page_title_color', '#3c4542'),
(1032, 163, '_page_title_color', 'field_5afa4a216bff6'),
(1033, 163, 'page_subheading', '<h1>Rethinking the commercial real estate lease</h1>'),
(1034, 163, '_page_subheading', 'field_5af83db84808e'),
(1035, 163, 'background', 'video'),
(1036, 163, '_background', 'field_5af83c494f983'),
(1037, 163, 'background_video', '150'),
(1038, 163, '_background_video', 'field_5af83cef4f986'),
(1039, 163, 'background_color', '#fc4513'),
(1040, 163, '_background_color', 'field_5af83ca54f984'),
(1041, 164, 'page_title_color', '#3c4542'),
(1042, 164, '_page_title_color', 'field_5afa4a216bff6'),
(1043, 164, 'page_subheading', '<h1>Rethinking the commercial <span class="ff-hn">real estate lease</span></h1>'),
(1044, 164, '_page_subheading', 'field_5af83db84808e'),
(1045, 164, 'background', 'video'),
(1046, 164, '_background', 'field_5af83c494f983'),
(1047, 164, 'background_video', '150'),
(1048, 164, '_background_video', 'field_5af83cef4f986'),
(1049, 164, 'background_color', '#fc4513'),
(1050, 164, '_background_color', 'field_5af83ca54f984'),
(1051, 165, 'page_title_color', '#3c4542'),
(1052, 165, '_page_title_color', 'field_5afa4a216bff6'),
(1053, 165, 'page_subheading', '<h1 style="font-size: 52px;">Rethinking the commercial <span class="ff-hn">real estate lease</span><span class="primary-color big-dot">.</span></h1>\r\n<a class="button button__cta button__cta--dark" href="/#!">See what’s possible »</a>'),
(1054, 165, '_page_subheading', 'field_5af83db84808e'),
(1055, 165, 'background', 'video'),
(1056, 165, '_background', 'field_5af83c494f983'),
(1057, 165, 'background_video', '150'),
(1058, 165, '_background_video', 'field_5af83cef4f986'),
(1059, 165, 'background_color', '#fc4513'),
(1060, 165, '_background_color', 'field_5af83ca54f984'),
(1061, 166, 'page_title_color', '#3c4542'),
(1062, 166, '_page_title_color', 'field_5afa4a216bff6'),
(1063, 166, 'page_subheading', '<h1>Rethinking the commercial <span class="ff-hn light">real estate lease</span><span class="primary-color big-dot">.</span></h1>\r\n<a class="button button__cta button__cta--dark" href="/#!">See what’s possible »</a>'),
(1064, 166, '_page_subheading', 'field_5af83db84808e'),
(1065, 166, 'background', 'video'),
(1066, 166, '_background', 'field_5af83c494f983'),
(1067, 166, 'background_video', '150'),
(1068, 166, '_background_video', 'field_5af83cef4f986'),
(1069, 166, 'background_color', '#fc4513'),
(1070, 166, '_background_color', 'field_5af83ca54f984'),
(1071, 167, 'page_title_color', '#3c4542'),
(1072, 167, '_page_title_color', 'field_5afa4a216bff6'),
(1073, 167, 'page_subheading', '<h1>Rethinking the commercial <span class="ff-hn lighter">real estate lease</span><span class="primary-color big-dot">.</span></h1>\r\n<a class="button button__cta button__cta--dark" href="/#!">See what’s possible »</a>'),
(1074, 167, '_page_subheading', 'field_5af83db84808e'),
(1075, 167, 'background', 'video'),
(1076, 167, '_background', 'field_5af83c494f983'),
(1077, 167, 'background_video', '150'),
(1078, 167, '_background_video', 'field_5af83cef4f986'),
(1079, 167, 'background_color', '#fc4513'),
(1080, 167, '_background_color', 'field_5af83ca54f984'),
(1081, 168, 'page_title_color', '#3c4542'),
(1082, 168, '_page_title_color', 'field_5afa4a216bff6'),
(1083, 168, 'page_subheading', '<h1 class="secondary-color">Rethinking the commercial <span class="ff-hn lighter">real estate lease</span><span class="primary-color big-dot">.</span></h1>\r\n<a class="button button__cta button__cta--dark" href="/#!">See what’s possible »</a>'),
(1084, 168, '_page_subheading', 'field_5af83db84808e'),
(1085, 168, 'background', 'video'),
(1086, 168, '_background', 'field_5af83c494f983'),
(1087, 168, 'background_video', '150'),
(1088, 168, '_background_video', 'field_5af83cef4f986'),
(1089, 168, 'background_color', '#fc4513'),
(1090, 168, '_background_color', 'field_5af83ca54f984'),
(1091, 37, 'case_study_blocks_3_image_vertical_align', 'center'),
(1092, 37, '_case_study_blocks_3_image_vertical_align', 'field_5afc6a8b48683'),
(1093, 37, 'case_study_blocks_3_text_color', '#ffffff'),
(1094, 37, '_case_study_blocks_3_text_color', 'field_5afc696ed6bbe'),
(1095, 171, '_wp_attached_file', '2018/05/home-cta.png'),
(1096, 171, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:401;s:6:"height";i:366;s:4:"file";s:20:"2018/05/home-cta.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"home-cta-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:20:"home-cta-300x274.png";s:5:"width";i:300;s:6:"height";i:274;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:20:"home-cta-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1097, 5, 'case_study_blocks_0_cta_image', '171'),
(1098, 5, '_case_study_blocks_0_cta_image', 'field_5afafa71e55a6'),
(1099, 5, 'case_study_blocks_0_image_vertical_align', 'bottom'),
(1100, 5, '_case_study_blocks_0_image_vertical_align', 'field_5afc6a8b48683'),
(1101, 5, 'case_study_blocks_0_cta_title', 'Reading is'),
(1102, 5, '_case_study_blocks_0_cta_title', 'field_5afaf4e378118'),
(1103, 5, 'case_study_blocks_0_cta_subtitle', 'believing:'),
(1104, 5, '_case_study_blocks_0_cta_subtitle', 'field_5afaf4ee78119'),
(1105, 5, 'case_study_blocks_0_cta_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet hendrerit libero.'),
(1106, 5, '_case_study_blocks_0_cta_description', 'field_5afaf66c7ce55'),
(1107, 5, 'case_study_blocks_0_cta_button_title', 'Download eBook »'),
(1108, 5, '_case_study_blocks_0_cta_button_title', 'field_5afaf5107811a'),
(1109, 5, 'case_study_blocks_0_cta_button_link', 'https://delindesign.com'),
(1110, 5, '_case_study_blocks_0_cta_button_link', 'field_5afaf5217811b'),
(1111, 5, 'case_study_blocks_0_text_color', '#3c4542'),
(1112, 5, '_case_study_blocks_0_text_color', 'field_5afc696ed6bbe'),
(1113, 5, 'case_study_blocks_0_block_background_color', '#ffffff'),
(1114, 5, '_case_study_blocks_0_block_background_color', 'field_5afaf3fa78117'),
(1115, 5, 'case_study_blocks', 'a:1:{i:0;s:9:"cta_block";}'),
(1116, 5, '_case_study_blocks', 'field_5afaf0ea2cc83'),
(1117, 172, 'page_title_color', '#3c4542'),
(1118, 172, '_page_title_color', 'field_5afa4a216bff6'),
(1119, 172, 'page_subheading', '<h1 class="secondary-color">Rethinking the commercial <span class="ff-hn lighter">real estate lease</span><span class="primary-color big-dot">.</span></h1>\r\n<a class="button button__cta button__cta--dark" href="/#!">See what’s possible »</a>'),
(1120, 172, '_page_subheading', 'field_5af83db84808e'),
(1121, 172, 'background', 'video'),
(1122, 172, '_background', 'field_5af83c494f983'),
(1123, 172, 'background_video', '150'),
(1124, 172, '_background_video', 'field_5af83cef4f986'),
(1125, 172, 'background_color', '#fc4513'),
(1126, 172, '_background_color', 'field_5af83ca54f984'),
(1127, 172, 'case_study_blocks_0_cta_image', '171'),
(1128, 172, '_case_study_blocks_0_cta_image', 'field_5afafa71e55a6'),
(1129, 172, 'case_study_blocks_0_image_vertical_align', 'bottom'),
(1130, 172, '_case_study_blocks_0_image_vertical_align', 'field_5afc6a8b48683'),
(1131, 172, 'case_study_blocks_0_cta_title', 'Reading is'),
(1132, 172, '_case_study_blocks_0_cta_title', 'field_5afaf4e378118'),
(1133, 172, 'case_study_blocks_0_cta_subtitle', 'believing:'),
(1134, 172, '_case_study_blocks_0_cta_subtitle', 'field_5afaf4ee78119'),
(1135, 172, 'case_study_blocks_0_cta_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet hendrerit libero.'),
(1136, 172, '_case_study_blocks_0_cta_description', 'field_5afaf66c7ce55'),
(1137, 172, 'case_study_blocks_0_cta_button_title', 'Download eBook »'),
(1138, 172, '_case_study_blocks_0_cta_button_title', 'field_5afaf5107811a'),
(1139, 172, 'case_study_blocks_0_cta_button_link', 'https://delindesign.com'),
(1140, 172, '_case_study_blocks_0_cta_button_link', 'field_5afaf5217811b'),
(1141, 172, 'case_study_blocks_0_text_color', '#3c4542'),
(1142, 172, '_case_study_blocks_0_text_color', 'field_5afc696ed6bbe'),
(1143, 172, 'case_study_blocks_0_block_background_color', '#ffffff'),
(1144, 172, '_case_study_blocks_0_block_background_color', 'field_5afaf3fa78117'),
(1145, 172, 'case_study_blocks', 'a:1:{i:0;s:9:"cta_block";}'),
(1146, 172, '_case_study_blocks', 'field_5afaf0ea2cc83'),
(1147, 174, '_wp_attached_file', '2018/05/video-poster.png'),
(1148, 174, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:746;s:4:"file";s:24:"2018/05/video-poster.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"video-poster-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"video-poster-300x187.png";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:24:"video-poster-768x477.png";s:5:"width";i:768;s:6:"height";i:477;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:25:"video-poster-1024x637.png";s:5:"width";i:1024;s:6:"height";i:637;s:9:"mime-type";s:9:"image/png";}s:11:"cover_small";a:4:{s:4:"file";s:24:"video-poster-400x205.png";s:5:"width";i:400;s:6:"height";i:205;s:9:"mime-type";s:9:"image/png";}s:11:"cover_large";a:4:{s:4:"file";s:25:"video-poster-1200x615.png";s:5:"width";i:1200;s:6:"height";i:615;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1149, 5, 'background_video_poster', '174'),
(1150, 5, '_background_video_poster', 'field_5afc7907d71fd'),
(1151, 175, 'page_title_color', '#3c4542'),
(1152, 175, '_page_title_color', 'field_5afa4a216bff6'),
(1153, 175, 'page_subheading', '<h1 class="secondary-color">Rethinking the commercial <span class="ff-hn lighter">real estate lease</span><span class="primary-color big-dot">.</span></h1>\r\n<a class="button button__cta button__cta--dark" href="/#!">See what’s possible »</a>'),
(1154, 175, '_page_subheading', 'field_5af83db84808e'),
(1155, 175, 'background', 'video'),
(1156, 175, '_background', 'field_5af83c494f983'),
(1157, 175, 'background_video', '150'),
(1158, 175, '_background_video', 'field_5af83cef4f986'),
(1159, 175, 'background_color', '#fc4513'),
(1160, 175, '_background_color', 'field_5af83ca54f984'),
(1161, 175, 'case_study_blocks_0_cta_image', '171'),
(1162, 175, '_case_study_blocks_0_cta_image', 'field_5afafa71e55a6'),
(1163, 175, 'case_study_blocks_0_image_vertical_align', 'bottom'),
(1164, 175, '_case_study_blocks_0_image_vertical_align', 'field_5afc6a8b48683'),
(1165, 175, 'case_study_blocks_0_cta_title', 'Reading is'),
(1166, 175, '_case_study_blocks_0_cta_title', 'field_5afaf4e378118'),
(1167, 175, 'case_study_blocks_0_cta_subtitle', 'believing:'),
(1168, 175, '_case_study_blocks_0_cta_subtitle', 'field_5afaf4ee78119'),
(1169, 175, 'case_study_blocks_0_cta_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet hendrerit libero.'),
(1170, 175, '_case_study_blocks_0_cta_description', 'field_5afaf66c7ce55'),
(1171, 175, 'case_study_blocks_0_cta_button_title', 'Download eBook »'),
(1172, 175, '_case_study_blocks_0_cta_button_title', 'field_5afaf5107811a'),
(1173, 175, 'case_study_blocks_0_cta_button_link', 'https://delindesign.com'),
(1174, 175, '_case_study_blocks_0_cta_button_link', 'field_5afaf5217811b'),
(1175, 175, 'case_study_blocks_0_text_color', '#3c4542'),
(1176, 175, '_case_study_blocks_0_text_color', 'field_5afc696ed6bbe'),
(1177, 175, 'case_study_blocks_0_block_background_color', '#ffffff'),
(1178, 175, '_case_study_blocks_0_block_background_color', 'field_5afaf3fa78117'),
(1179, 175, 'case_study_blocks', 'a:1:{i:0;s:9:"cta_block";}'),
(1180, 175, '_case_study_blocks', 'field_5afaf0ea2cc83'),
(1181, 175, 'background_video_poster', '174'),
(1182, 175, '_background_video_poster', 'field_5afc7907d71fd');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-05-02 18:19:49', '2018-05-02 18:19:49', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2018-05-02 18:19:49', '2018-05-02 18:19:49', '', 0, 'http://leasepilot.dev.cc/?p=1', 0, 'post', '', 1),
(5, 1, '2018-05-03 13:10:40', '2018-05-03 13:10:40', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-05-16 18:32:29', '2018-05-16 18:32:29', '', 0, 'http://leasepilot.dev.cc/?page_id=5', 0, 'page', '', 0),
(6, 1, '2018-05-03 13:10:40', '2018-05-03 13:10:40', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-03 13:10:40', '2018-05-03 13:10:40', '', 5, 'http://leasepilot.dev.cc/2018/05/03/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2018-05-03 13:47:15', '2018-05-03 13:47:15', '', 'Case Study 1', '', 'publish', 'closed', 'closed', '', 'case-study-1', '', '', '2018-05-03 14:10:11', '2018-05-03 14:10:11', '', 0, 'http://leasepilot.dev.cc/?post_type=case_study&#038;p=7', 0, 'case_study', '', 0),
(8, 1, '2018-05-03 13:48:47', '2018-05-03 13:48:47', '', 'Product', '', 'publish', 'closed', 'closed', '', 'product', '', '', '2018-05-03 13:54:22', '2018-05-03 13:54:22', '', 0, 'http://leasepilot.dev.cc/?page_id=8', 0, 'page', '', 0),
(9, 1, '2018-05-03 13:48:47', '2018-05-03 13:48:47', '', 'Product', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-05-03 13:48:47', '2018-05-03 13:48:47', '', 8, 'http://leasepilot.dev.cc/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2018-05-03 13:48:54', '2018-05-03 13:48:54', '', 'About us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2018-05-16 13:33:44', '2018-05-16 13:33:44', '', 0, 'http://leasepilot.dev.cc/?page_id=10', 0, 'page', '', 0),
(11, 1, '2018-05-03 13:48:54', '2018-05-03 13:48:54', '', 'About', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-03 13:48:54', '2018-05-03 13:48:54', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2018-05-03 14:09:47', '2018-05-03 14:09:47', '', 'Title goes here', '', 'publish', 'closed', 'closed', '', 'resource-1', '', '', '2018-05-15 19:05:58', '2018-05-15 19:05:58', '', 0, 'http://leasepilot.dev.cc/?post_type=resource&#038;p=12', 0, 'resource', '', 0),
(13, 1, '2018-05-03 15:03:49', '2018-05-03 15:03:49', ' ', '', '', 'publish', 'closed', 'closed', '', '13', '', '', '2018-05-15 02:40:36', '2018-05-15 02:40:36', '', 0, 'http://leasepilot.dev.cc/?p=13', 2, 'nav_menu_item', '', 0),
(14, 1, '2018-05-03 15:03:49', '2018-05-03 15:03:49', ' ', '', '', 'publish', 'closed', 'closed', '', '14', '', '', '2018-05-15 02:40:36', '2018-05-15 02:40:36', '', 0, 'http://leasepilot.dev.cc/?p=14', 1, 'nav_menu_item', '', 0),
(17, 1, '2018-05-03 15:03:49', '2018-05-03 15:03:49', '', 'Request a Demo', '', 'publish', 'closed', 'closed', '', 'request-a-demo', '', '', '2018-05-15 02:40:36', '2018-05-15 02:40:36', '', 0, 'http://leasepilot.dev.cc/?p=17', 7, 'nav_menu_item', '', 0),
(18, 1, '2018-05-03 16:37:49', '2018-05-03 16:37:49', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-05-03 16:37:49', '2018-05-03 16:37:49', '', 0, 'http://leasepilot.dev.cc/?page_id=18', 0, 'page', '', 0),
(19, 1, '2018-05-03 16:37:49', '2018-05-03 16:37:49', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-05-03 16:37:49', '2018-05-03 16:37:49', '', 18, 'http://leasepilot.dev.cc/18-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2018-05-03 16:43:28', '2018-05-03 16:43:28', '', 'Login', '', 'publish', 'closed', 'closed', '', 'login', '', '', '2018-05-11 17:40:49', '2018-05-11 17:40:49', '', 0, 'http://leasepilot.dev.cc/?p=22', 1, 'nav_menu_item', '', 0),
(23, 1, '2018-05-10 19:05:44', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-05-10 19:05:44', '0000-00-00 00:00:00', '', 0, 'http://leasepilot.dev.cc/?p=23', 0, 'post', '', 0),
(25, 1, '2018-05-11 16:57:15', '2018-05-11 16:57:15', '', 'casto-cover', '', 'inherit', 'open', 'closed', '', 'casto-cover', '', '', '2018-05-14 17:06:59', '2018-05-14 17:06:59', '', 39, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/casto-cover.png', 0, 'attachment', 'image/png', 0),
(26, 1, '2018-05-11 16:57:15', '2018-05-11 16:57:15', '', 'casto', '', 'inherit', 'open', 'closed', '', 'casto-2', '', '', '2018-05-14 17:07:54', '2018-05-14 17:07:54', '', 37, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/casto.png', 0, 'attachment', 'image/png', 0),
(27, 1, '2018-05-11 16:57:15', '2018-05-11 16:57:15', '', 'entrata', '', 'inherit', 'open', 'closed', '', 'entrata-2', '', '', '2018-05-14 17:08:46', '2018-05-14 17:08:46', '', 34, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/entrata.png', 0, 'attachment', 'image/png', 0),
(28, 1, '2018-05-11 16:57:15', '2018-05-11 16:57:15', '', 'nestio', '', 'inherit', 'open', 'closed', '', 'nestio-2', '', '', '2018-05-14 17:08:29', '2018-05-14 17:08:29', '', 35, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/nestio.png', 0, 'attachment', 'image/png', 0),
(29, 1, '2018-05-11 16:57:16', '2018-05-11 16:57:16', '', 'real-estate-software', '', 'inherit', 'open', 'closed', '', 'real-estate-software-2', '', '', '2018-05-15 15:59:16', '2018-05-15 15:59:16', '', 39, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/real-estate-software.png', 0, 'attachment', 'image/png', 0),
(30, 1, '2018-05-11 16:57:16', '2018-05-11 16:57:16', '', 'vts', '', 'inherit', 'open', 'closed', '', 'vts-2', '', '', '2018-05-14 17:08:13', '2018-05-14 17:08:13', '', 36, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/vts.png', 0, 'attachment', 'image/png', 0),
(31, 1, '2018-05-11 16:57:16', '2018-05-11 16:57:16', '', 'yardi', '', 'inherit', 'open', 'closed', '', 'yardi-2', '', '', '2018-05-14 17:07:01', '2018-05-14 17:07:01', '', 38, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/yardi.png', 0, 'attachment', 'image/png', 0),
(34, 1, '2018-05-11 16:59:01', '2018-05-11 16:59:01', '', 'Entrata', '', 'publish', 'closed', 'closed', '', 'entrata', '', '', '2018-05-14 17:08:46', '2018-05-14 17:08:46', '', 0, 'http://leasepilot.dev.cc/?post_type=case-study&#038;p=34', 0, 'case-study', '', 0),
(35, 1, '2018-05-11 16:59:15', '2018-05-11 16:59:15', '', 'Nestio', '', 'publish', 'closed', 'closed', '', 'nestio', '', '', '2018-05-14 17:08:29', '2018-05-14 17:08:29', '', 0, 'http://leasepilot.dev.cc/?post_type=case-study&#038;p=35', 0, 'case-study', '', 0),
(36, 1, '2018-05-11 16:59:28', '2018-05-11 16:59:28', '', 'VTS', '', 'publish', 'closed', 'closed', '', 'vts', '', '', '2018-05-14 17:08:13', '2018-05-14 17:08:13', '', 0, 'http://leasepilot.dev.cc/?post_type=case-study&#038;p=36', 0, 'case-study', '', 0),
(37, 1, '2018-05-11 16:59:45', '2018-05-11 16:59:45', '', 'Casto', '', 'publish', 'closed', 'closed', '', 'casto', '', '', '2018-05-16 17:48:30', '2018-05-16 17:48:30', '', 0, 'http://leasepilot.dev.cc/?post_type=case-study&#038;p=37', 0, 'case-study', '', 0),
(38, 1, '2018-05-11 16:59:56', '2018-05-11 16:59:56', '', 'Yardi', '', 'publish', 'closed', 'closed', '', 'yardi', '', '', '2018-05-14 17:07:01', '2018-05-14 17:07:01', '', 0, 'http://leasepilot.dev.cc/?post_type=case-study&#038;p=38', 0, 'case-study', '', 0),
(39, 1, '2018-05-11 17:00:15', '2018-05-11 17:00:15', '', 'Real Estate Software', '', 'publish', 'closed', 'closed', '', 'real-estate-software', '', '', '2018-05-15 15:59:17', '2018-05-15 15:59:17', '', 0, 'http://leasepilot.dev.cc/?post_type=case-study&#038;p=39', 0, 'case-study', '', 0),
(40, 1, '2018-05-11 17:41:09', '2018-05-11 17:41:09', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2018-05-15 02:40:36', '2018-05-15 02:40:36', '', 0, 'http://leasepilot.dev.cc/?p=40', 5, 'nav_menu_item', '', 0),
(41, 1, '2018-05-11 18:12:28', '2018-05-11 18:12:28', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2018-05-11 18:44:35', '2018-05-11 18:44:35', '', 0, 'http://leasepilot.dev.cc/?p=41', 1, 'nav_menu_item', '', 0),
(42, 1, '2018-05-11 18:12:28', '2018-05-11 18:12:28', '', 'Data <br>to Document', '', 'publish', 'closed', 'closed', '', 'data-to-document', '', '', '2018-05-11 18:44:35', '2018-05-11 18:44:35', '', 0, 'http://leasepilot.dev.cc/?p=42', 2, 'nav_menu_item', '', 0),
(43, 1, '2018-05-11 18:12:28', '2018-05-11 18:12:28', '', 'Steamline, Optimize, Automate', '', 'publish', 'closed', 'closed', '', 'steamline-optimize-automate', '', '', '2018-05-11 18:44:35', '2018-05-11 18:44:35', '', 0, 'http://leasepilot.dev.cc/?p=43', 3, 'nav_menu_item', '', 0),
(44, 1, '2018-05-11 18:12:28', '2018-05-11 18:12:28', '', 'Future Positive State', '', 'publish', 'closed', 'closed', '', 'future-positive-state', '', '', '2018-05-11 18:44:35', '2018-05-11 18:44:35', '', 0, 'http://leasepilot.dev.cc/?p=44', 4, 'nav_menu_item', '', 0),
(45, 1, '2018-05-11 18:12:58', '2018-05-11 18:12:58', ' ', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2018-05-11 18:12:58', '2018-05-11 18:12:58', '', 0, 'http://leasepilot.dev.cc/?p=45', 1, 'nav_menu_item', '', 0),
(46, 1, '2018-05-11 18:12:58', '2018-05-11 18:12:58', '', 'Careers', '', 'publish', 'closed', 'closed', '', 'careers', '', '', '2018-05-11 18:12:58', '2018-05-11 18:12:58', '', 0, 'http://leasepilot.dev.cc/?p=46', 2, 'nav_menu_item', '', 0),
(47, 1, '2018-05-11 18:13:51', '2018-05-11 18:13:51', '', 'Case Studies', '', 'publish', 'closed', 'closed', '', 'case-studies-2', '', '', '2018-05-11 18:13:51', '2018-05-11 18:13:51', '', 0, 'http://leasepilot.dev.cc/?p=47', 1, 'nav_menu_item', '', 0),
(48, 1, '2018-05-11 18:14:22', '2018-05-11 18:14:22', '', 'Resources', '', 'publish', 'closed', 'closed', '', 'resources-2', '', '', '2018-05-11 18:14:22', '2018-05-11 18:14:22', '', 0, 'http://leasepilot.dev.cc/?p=48', 1, 'nav_menu_item', '', 0),
(49, 1, '2018-05-13 00:16:47', '2018-05-13 00:16:47', '', 'About us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-13 00:16:47', '2018-05-13 00:16:47', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2018-05-13 13:26:57', '2018-05-13 13:26:57', 'a:7:{s:8:"location";a:2:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:10:"case-study";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Page', 'page', 'publish', 'closed', 'closed', '', 'group_5af83c3f799eb', '', '', '2018-05-16 18:32:02', '2018-05-16 18:32:02', '', 0, 'http://leasepilot.dev.cc/?post_type=acf-field-group&#038;p=50', 0, 'acf-field-group', '', 0),
(51, 1, '2018-05-13 13:26:57', '2018-05-13 13:26:57', 'a:12:{s:4:"type";s:5:"radio";s:12:"instructions";s:34:"Background for page header section";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:4:{s:4:"none";s:4:"None";s:5:"color";s:5:"Color";s:5:"image";s:5:"Image";s:5:"video";s:5:"Video";}s:10:"allow_null";i:0;s:12:"other_choice";i:0;s:17:"save_other_choice";i:0;s:13:"default_value";s:4:"none";s:6:"layout";s:10:"horizontal";s:13:"return_format";s:5:"value";}', 'Background', 'background', 'publish', 'closed', 'closed', '', 'field_5af83c494f983', '', '', '2018-05-15 02:48:43', '2018-05-15 02:48:43', '', 50, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=51', 2, 'acf-field', '', 0),
(52, 1, '2018-05-13 13:26:57', '2018-05-13 13:26:57', 'a:6:{s:4:"type";s:12:"color_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:7:"#FFFFFF";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_5af83c494f983";s:8:"operator";s:2:"==";s:5:"value";s:5:"color";}}}}', 'Background Color', 'background_color', 'publish', 'closed', 'closed', '', 'field_5af83ca54f984', '', '', '2018-05-15 02:48:43', '2018-05-15 02:48:43', '', 50, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=52', 3, 'acf-field', '', 0),
(53, 1, '2018-05-13 13:26:57', '2018-05-13 13:26:57', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:11:"cover_small";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_5af83c494f983";s:8:"operator";s:2:"==";s:5:"value";s:5:"image";}}}}', 'Background Image', 'background_image', 'publish', 'closed', 'closed', '', 'field_5af83ccd4f985', '', '', '2018-05-15 02:48:43', '2018-05-15 02:48:43', '', 50, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=53', 4, 'acf-field', '', 0),
(54, 1, '2018-05-13 13:26:57', '2018-05-13 13:26:57', 'a:10:{s:4:"type";s:4:"file";s:12:"instructions";s:16:"Background video";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:8:"min_size";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_5af83c494f983";s:8:"operator";s:2:"==";s:5:"value";s:5:"video";}}}}', 'Background Video', 'background_video', 'publish', 'closed', 'closed', '', 'field_5af83cef4f986', '', '', '2018-05-16 16:12:08', '2018-05-16 16:12:08', '', 50, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=54', 5, 'acf-field', '', 0),
(55, 1, '2018-05-13 13:32:17', '2018-05-13 13:32:17', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Page Subheading', 'page_subheading', 'publish', 'closed', 'closed', '', 'field_5af83db84808e', '', '', '2018-05-15 02:50:18', '2018-05-15 02:50:18', '', 50, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=55', 1, 'acf-field', '', 0),
(56, 1, '2018-05-13 13:33:16', '2018-05-13 13:33:16', '', 'about-cover', '', 'inherit', 'open', 'closed', '', 'about-cover', '', '', '2018-05-13 13:33:19', '2018-05-13 13:33:19', '', 10, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/about-cover.png', 0, 'attachment', 'image/png', 0),
(57, 1, '2018-05-13 13:33:25', '2018-05-13 13:33:25', '', 'About us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-13 13:33:25', '2018-05-13 13:33:25', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2018-05-14 13:55:22', '2018-05-14 13:55:22', '', 'Gabriel', '', 'inherit', 'open', 'closed', '', 'gabriel', '', '', '2018-05-14 14:00:27', '2018-05-14 14:00:27', '', 10, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/Gabriel.png', 0, 'attachment', 'image/png', 0),
(59, 1, '2018-05-14 13:55:22', '2018-05-14 13:55:22', '', 'Itzik', '', 'inherit', 'open', 'closed', '', 'itzik', '', '', '2018-05-14 14:00:27', '2018-05-14 14:00:27', '', 10, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/Itzik.png', 0, 'attachment', 'image/png', 0),
(60, 1, '2018-05-14 13:55:23', '2018-05-14 13:55:23', '', 'Nadine', '', 'inherit', 'open', 'closed', '', 'nadine', '', '', '2018-05-14 14:00:27', '2018-05-14 14:00:27', '', 10, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/Nadine.png', 0, 'attachment', 'image/png', 0),
(61, 1, '2018-05-14 13:57:39', '2018-05-14 13:57:39', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:29:"page-templates/page-about.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Page About', 'page-about', 'publish', 'closed', 'closed', '', 'group_5af99551d65dd', '', '', '2018-05-14 14:01:14', '2018-05-14 14:01:14', '', 0, 'http://leasepilot.dev.cc/?post_type=acf-field-group&#038;p=61', 0, 'acf-field-group', '', 0),
(62, 1, '2018-05-14 13:57:39', '2018-05-14 13:57:39', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:10:"Add Person";}', 'People', 'people', 'publish', 'closed', 'closed', '', 'field_5af99562e81b8', '', '', '2018-05-14 13:58:11', '2018-05-14 13:58:11', '', 61, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=62', 0, 'acf-field', '', 0),
(63, 1, '2018-05-14 13:57:39', '2018-05-14 13:57:39', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Avatar', 'avatar', 'publish', 'closed', 'closed', '', 'field_5af9957ee81b9', '', '', '2018-05-14 13:57:39', '2018-05-14 13:57:39', '', 62, 'http://leasepilot.dev.cc/?post_type=acf-field&p=63', 0, 'acf-field', '', 0),
(64, 1, '2018-05-14 13:57:39', '2018-05-14 13:57:39', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:10:"First name";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'First Name', 'first_name', 'publish', 'closed', 'closed', '', 'field_5af99594e81ba', '', '', '2018-05-14 13:57:39', '2018-05-14 13:57:39', '', 62, 'http://leasepilot.dev.cc/?post_type=acf-field&p=64', 1, 'acf-field', '', 0),
(65, 1, '2018-05-14 13:57:39', '2018-05-14 13:57:39', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:9:"Last name";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Last Name', 'last_name', 'publish', 'closed', 'closed', '', 'field_5af995b2e81bb', '', '', '2018-05-14 14:01:14', '2018-05-14 14:01:14', '', 62, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=65', 3, 'acf-field', '', 0),
(66, 1, '2018-05-14 13:57:39', '2018-05-14 13:57:39', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:8:"Position";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Position', 'position', 'publish', 'closed', 'closed', '', 'field_5af995c2e81bc', '', '', '2018-05-14 14:01:14', '2018-05-14 14:01:14', '', 62, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=66', 4, 'acf-field', '', 0),
(67, 1, '2018-05-14 14:00:27', '2018-05-14 14:00:27', '', 'About us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-14 14:00:27', '2018-05-14 14:00:27', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2018-05-14 14:01:14', '2018-05-14 14:01:14', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:21:"Leave blank for space";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name Separator', 'name_separator', 'publish', 'closed', 'closed', '', 'field_5af99685b6681', '', '', '2018-05-14 14:01:14', '2018-05-14 14:01:14', '', 62, 'http://leasepilot.dev.cc/?post_type=acf-field&p=68', 2, 'acf-field', '', 0),
(69, 1, '2018-05-14 14:01:24', '2018-05-14 14:01:24', '', 'About us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-14 14:01:24', '2018-05-14 14:01:24', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-05-14 15:51:45', '2018-05-14 15:51:45', '', 'Login', '', 'publish', 'closed', 'closed', '', 'login-2', '', '', '2018-05-15 02:40:36', '2018-05-15 02:40:36', '', 0, 'http://leasepilot.dev.cc/?p=70', 6, 'nav_menu_item', '', 0),
(71, 1, '2018-05-14 16:29:34', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-05-14 16:29:34', '0000-00-00 00:00:00', '', 0, 'http://leasepilot.dev.cc/?post_type=acf-field-group&p=71', 0, 'acf-field-group', '', 0),
(72, 1, '2018-05-14 16:30:50', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-05-14 16:30:50', '0000-00-00 00:00:00', '', 0, 'http://leasepilot.dev.cc/?post_type=acf-field-group&p=72', 0, 'acf-field-group', '', 0),
(73, 1, '2018-05-14 17:01:39', '2018-05-14 17:01:39', '', 'billboard-case-study', '', 'inherit', 'open', 'closed', '', 'billboard-case-study', '', '', '2018-05-15 03:20:38', '2018-05-15 03:20:38', '', 87, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/billboard-case-study.png', 0, 'attachment', 'image/png', 0),
(74, 1, '2018-05-14 17:06:12', '2018-05-14 17:06:12', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:10:"case-study";}}}s:8:"position";s:4:"side";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Case Study CPT', 'case-study-cpt', 'publish', 'closed', 'closed', '', 'group_5af9c180a54c1', '', '', '2018-05-15 14:38:07', '2018-05-15 14:38:07', '', 0, 'http://leasepilot.dev.cc/?post_type=acf-field-group&#038;p=74', 0, 'acf-field-group', '', 0),
(75, 1, '2018-05-14 17:06:12', '2018-05-14 17:06:12', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Case Study Logo in Archive Page', 'case_study_logo', 'publish', 'closed', 'closed', '', 'field_5af9c192d0d30', '', '', '2018-05-15 13:12:09', '2018-05-15 13:12:09', '', 74, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=75', 0, 'acf-field', '', 0),
(76, 1, '2018-05-14 17:06:12', '2018-05-14 17:06:12', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Case Study Cover in Archive Page', 'case_study_cover', 'publish', 'closed', 'closed', '', 'field_5af9c1d9d0d31', '', '', '2018-05-15 13:12:09', '2018-05-15 13:12:09', '', 74, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=76', 2, 'acf-field', '', 0),
(87, 1, '2018-05-15 02:39:16', '2018-05-15 02:39:16', '', 'Case Studies', '', 'publish', 'closed', 'closed', '', 'case-studies', '', '', '2018-05-15 19:15:13', '2018-05-15 19:15:13', '', 0, 'http://leasepilot.dev.cc/?page_id=87', 0, 'page', '', 0),
(88, 1, '2018-05-15 02:39:16', '2018-05-15 02:39:16', '', 'Case Studies', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2018-05-15 02:39:16', '2018-05-15 02:39:16', '', 87, 'http://leasepilot.dev.cc/87-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2018-05-15 02:39:30', '2018-05-15 02:39:30', '', 'Case Studies', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2018-05-15 02:39:30', '2018-05-15 02:39:30', '', 87, 'http://leasepilot.dev.cc/87-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2018-05-15 02:39:53', '2018-05-15 02:39:53', ' ', '', '', 'publish', 'closed', 'closed', '', '90', '', '', '2018-05-15 02:40:36', '2018-05-15 02:40:36', '', 0, 'http://leasepilot.dev.cc/?p=90', 3, 'nav_menu_item', '', 0),
(91, 1, '2018-05-15 02:40:05', '2018-05-15 02:40:05', '', 'Resources', '', 'publish', 'closed', 'closed', '', 'resources', '', '', '2018-05-15 19:15:17', '2018-05-15 19:15:17', '', 0, 'http://leasepilot.dev.cc/?page_id=91', 0, 'page', '', 0),
(92, 1, '2018-05-15 02:40:05', '2018-05-15 02:40:05', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2018-05-15 02:40:05', '2018-05-15 02:40:05', '', 91, 'http://leasepilot.dev.cc/91-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2018-05-15 02:40:36', '2018-05-15 02:40:36', ' ', '', '', 'publish', 'closed', 'closed', '', '93', '', '', '2018-05-15 02:40:36', '2018-05-15 02:40:36', '', 0, 'http://leasepilot.dev.cc/?p=93', 4, 'nav_menu_item', '', 0),
(94, 1, '2018-05-15 02:48:43', '2018-05-15 02:48:43', 'a:6:{s:4:"type";s:12:"color_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:7:"#fc4513";}', 'Page Title Color', 'page_title_color', 'publish', 'closed', 'closed', '', 'field_5afa4a216bff6', '', '', '2018-05-15 02:48:43', '2018-05-15 02:48:43', '', 50, 'http://leasepilot.dev.cc/?post_type=acf-field&p=94', 0, 'acf-field', '', 0),
(95, 1, '2018-05-15 02:51:42', '2018-05-15 02:51:42', '', 'About us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-15 02:51:42', '2018-05-15 02:51:42', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2018-05-15 02:54:29', '2018-05-15 02:54:29', '', 'Case Studies', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2018-05-15 02:54:29', '2018-05-15 02:54:29', '', 87, 'http://leasepilot.dev.cc/87-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2018-05-15 13:12:09', '2018-05-15 13:12:09', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Case Study Logo in Single Page', 'case_study_logo_single', 'publish', 'closed', 'closed', '', 'field_5afadc153c9e0', '', '', '2018-05-15 13:12:09', '2018-05-15 13:12:09', '', 74, 'http://leasepilot.dev.cc/?post_type=acf-field&p=97', 1, 'acf-field', '', 0),
(98, 1, '2018-05-15 13:12:23', '2018-05-15 13:12:23', '', 'casto-singular', '', 'inherit', 'open', 'closed', '', 'casto-singular', '', '', '2018-05-15 15:59:09', '2018-05-15 15:59:09', '', 37, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/casto-singular.png', 0, 'attachment', 'image/png', 0),
(99, 1, '2018-05-15 14:44:29', '2018-05-15 14:44:29', 'a:7:{s:8:"location";a:2:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:10:"case-study";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Page Blocks', 'page-blocks', 'publish', 'closed', 'closed', '', 'group_5afaf0d276359', '', '', '2018-05-16 17:31:04', '2018-05-16 17:31:04', '', 0, 'http://leasepilot.dev.cc/?post_type=acf-field-group&#038;p=99', 0, 'acf-field-group', '', 0),
(100, 1, '2018-05-15 14:44:29', '2018-05-15 14:44:29', 'a:9:{s:4:"type";s:16:"flexible_content";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"layouts";a:3:{s:13:"5afaf0f1e7a64";a:6:{s:3:"key";s:13:"5afaf0f1e7a64";s:5:"label";s:17:"Big Heading Block";s:4:"name";s:17:"big_heading_block";s:7:"display";s:5:"block";s:3:"min";s:0:"";s:3:"max";s:0:"";}s:13:"5afaf1902cc87";a:6:{s:3:"key";s:13:"5afaf1902cc87";s:5:"label";s:16:"Text Quote Block";s:4:"name";s:16:"text_quote_block";s:7:"display";s:3:"row";s:3:"min";s:0:"";s:3:"max";s:0:"";}s:13:"5afaf3fa78113";a:6:{s:3:"key";s:13:"5afaf3fa78113";s:5:"label";s:9:"CTA Block";s:4:"name";s:9:"cta_block";s:7:"display";s:3:"row";s:3:"min";s:0:"";s:3:"max";s:0:"";}}s:12:"button_label";s:9:"Add Block";s:3:"min";s:0:"";s:3:"max";s:0:"";}', 'Page Blocks', 'case_study_blocks', 'publish', 'closed', 'closed', '', 'field_5afaf0ea2cc83', '', '', '2018-05-16 17:29:32', '2018-05-16 17:29:32', '', 99, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=100', 0, 'acf-field', '', 0),
(101, 1, '2018-05-15 14:44:29', '2018-05-15 14:44:29', 'a:11:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf0f1e7a64";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Big Heading', 'big_heading', 'publish', 'closed', 'closed', '', 'field_5afaf1262cc84', '', '', '2018-05-15 14:44:29', '2018-05-15 14:44:29', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&p=101', 0, 'acf-field', '', 0),
(102, 1, '2018-05-15 14:44:29', '2018-05-15 14:44:29', 'a:7:{s:4:"type";s:12:"color_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf0f1e7a64";s:13:"default_value";s:7:"#fc4513";}', 'Text Color', 'text_color', 'publish', 'closed', 'closed', '', 'field_5afaf1492cc85', '', '', '2018-05-15 14:44:29', '2018-05-15 14:44:29', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&p=102', 1, 'acf-field', '', 0),
(103, 1, '2018-05-15 14:44:29', '2018-05-15 14:44:29', 'a:7:{s:4:"type";s:12:"color_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf0f1e7a64";s:13:"default_value";s:7:"#ffffff";}', 'Block Background Color', 'block_background_color', 'publish', 'closed', 'closed', '', 'field_5afaf1652cc86', '', '', '2018-05-15 14:44:29', '2018-05-15 14:44:29', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&p=103', 2, 'acf-field', '', 0),
(104, 1, '2018-05-15 14:44:29', '2018-05-15 14:44:29', 'a:11:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf1902cc87";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Block Title', 'block_title', 'publish', 'closed', 'closed', '', 'field_5afaf1eb2cc8b', '', '', '2018-05-15 14:44:29', '2018-05-15 14:44:29', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&p=104', 0, 'acf-field', '', 0),
(105, 1, '2018-05-15 14:44:29', '2018-05-15 14:44:29', 'a:11:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf1902cc87";s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Block Content', 'block_content', 'publish', 'closed', 'closed', '', 'field_5afaf2062cc8c', '', '', '2018-05-15 14:46:51', '2018-05-15 14:46:51', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=105', 2, 'acf-field', '', 0),
(106, 1, '2018-05-15 14:44:29', '2018-05-15 14:44:29', 'a:11:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf1902cc87";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Block Quote', 'block_quote', 'publish', 'closed', 'closed', '', 'field_5afaf2252cc8d', '', '', '2018-05-15 14:46:51', '2018-05-15 14:46:51', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=106', 1, 'acf-field', '', 0),
(107, 1, '2018-05-15 14:44:29', '2018-05-15 14:44:29', 'a:7:{s:4:"type";s:12:"color_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:3:"100";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf1902cc87";s:13:"default_value";s:7:"#ffffff";}', 'Block Background Color', 'block_background_color', 'publish', 'closed', 'closed', '', 'field_5afaf1902cc8a', '', '', '2018-05-15 14:57:56', '2018-05-15 14:57:56', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=107', 3, 'acf-field', '', 0),
(108, 1, '2018-05-15 14:57:56', '2018-05-15 14:57:56', 'a:11:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf3fa78113";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'CTA Title', 'cta_title', 'publish', 'closed', 'closed', '', 'field_5afaf4e378118', '', '', '2018-05-16 17:31:03', '2018-05-16 17:31:03', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=108', 2, 'acf-field', '', 0),
(109, 1, '2018-05-15 14:57:56', '2018-05-15 14:57:56', 'a:11:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf3fa78113";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'CTA Subtitle', 'cta_subtitle', 'publish', 'closed', 'closed', '', 'field_5afaf4ee78119', '', '', '2018-05-16 17:31:03', '2018-05-16 17:31:03', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=109', 3, 'acf-field', '', 0),
(110, 1, '2018-05-15 14:57:56', '2018-05-15 14:57:56', 'a:11:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf3fa78113";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'CTA Button Title', 'cta_button_title', 'publish', 'closed', 'closed', '', 'field_5afaf5107811a', '', '', '2018-05-16 17:31:03', '2018-05-16 17:31:03', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=110', 5, 'acf-field', '', 0),
(111, 1, '2018-05-15 14:57:56', '2018-05-15 14:57:56', 'a:8:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf3fa78113";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'CTA Button Link', 'cta_button_link', 'publish', 'closed', 'closed', '', 'field_5afaf5217811b', '', '', '2018-05-16 17:31:04', '2018-05-16 17:31:04', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=111', 6, 'acf-field', '', 0),
(112, 1, '2018-05-15 14:57:56', '2018-05-15 14:57:56', 'a:7:{s:4:"type";s:12:"color_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:3:"100";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf3fa78113";s:13:"default_value";s:7:"#ffffff";}', 'Block Background Color', 'block_background_color', 'publish', 'closed', 'closed', '', 'field_5afaf3fa78117', '', '', '2018-05-16 17:31:04', '2018-05-16 17:31:04', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=112', 8, 'acf-field', '', 0),
(113, 1, '2018-05-15 15:02:36', '2018-05-15 15:02:36', 'a:11:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf3fa78113";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:4;s:9:"new_lines";s:0:"";}', 'CTA Description', 'cta_description', 'publish', 'closed', 'closed', '', 'field_5afaf66c7ce55', '', '', '2018-05-16 17:31:03', '2018-05-16 17:31:03', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=113', 4, 'acf-field', '', 0),
(114, 1, '2018-05-15 15:19:34', '2018-05-15 15:19:34', 'a:16:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf3fa78113";s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'CTA Image', 'cta_image', 'publish', 'closed', 'closed', '', 'field_5afafa71e55a6', '', '', '2018-05-15 15:19:34', '2018-05-15 15:19:34', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&p=114', 0, 'acf-field', '', 0),
(115, 1, '2018-05-15 15:19:48', '2018-05-15 15:19:48', '', 'cta-img', '', 'inherit', 'open', 'closed', '', 'cta-img', '', '', '2018-05-15 15:19:49', '2018-05-15 15:19:49', '', 37, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/cta-img.png', 0, 'attachment', 'image/png', 0),
(116, 1, '2018-05-15 19:06:17', '2018-05-15 19:06:17', '', 'Title goes here', '', 'publish', 'closed', 'closed', '', 'title-goes-here', '', '', '2018-05-15 19:06:17', '2018-05-15 19:06:17', '', 0, 'http://leasepilot.dev.cc/?post_type=resource&#038;p=116', 0, 'resource', '', 0),
(117, 1, '2018-05-15 19:06:37', '2018-05-15 19:06:37', '', 'Title goes here', '', 'publish', 'closed', 'closed', '', 'title-goes-here-2', '', '', '2018-05-15 19:06:37', '2018-05-15 19:06:37', '', 0, 'http://leasepilot.dev.cc/?post_type=resource&#038;p=117', 0, 'resource', '', 0),
(118, 1, '2018-05-15 19:06:45', '2018-05-15 19:06:45', '', 'Title goes here', '', 'publish', 'closed', 'closed', '', 'title-goes-here-3', '', '', '2018-05-15 19:06:45', '2018-05-15 19:06:45', '', 0, 'http://leasepilot.dev.cc/?post_type=resource&#038;p=118', 0, 'resource', '', 0),
(119, 1, '2018-05-15 19:06:57', '2018-05-15 19:06:57', '', 'Title goes here', '', 'publish', 'closed', 'closed', '', 'title-goes-here-4', '', '', '2018-05-15 19:06:57', '2018-05-15 19:06:57', '', 0, 'http://leasepilot.dev.cc/?post_type=resource&#038;p=119', 0, 'resource', '', 0),
(120, 1, '2018-05-15 19:07:07', '2018-05-15 19:07:07', '', 'Title goes here', '', 'publish', 'closed', 'closed', '', 'title-goes-here-5', '', '', '2018-05-15 19:07:07', '2018-05-15 19:07:07', '', 0, 'http://leasepilot.dev.cc/?post_type=resource&#038;p=120', 0, 'resource', '', 0),
(121, 1, '2018-05-15 19:07:19', '2018-05-15 19:07:19', '', 'Title goes here', '', 'publish', 'closed', 'closed', '', 'title-goes-here-6', '', '', '2018-05-15 19:07:19', '2018-05-15 19:07:19', '', 0, 'http://leasepilot.dev.cc/?post_type=resource&#038;p=121', 0, 'resource', '', 0),
(122, 1, '2018-05-15 19:08:16', '2018-05-15 19:08:16', '', 'Title goes here', '', 'publish', 'closed', 'closed', '', 'title-goes-here-7', '', '', '2018-05-15 19:08:16', '2018-05-15 19:08:16', '', 0, 'http://leasepilot.dev.cc/?post_type=resource&#038;p=122', 0, 'resource', '', 0),
(123, 1, '2018-05-15 19:08:22', '2018-05-15 19:08:22', '', 'LeasePilot PPT', '', 'publish', 'closed', 'closed', '', 'title-goes-here-8', '', '', '2018-05-15 23:54:35', '2018-05-15 23:54:35', '', 0, 'http://leasepilot.dev.cc/?post_type=resource&#038;p=123', 0, 'resource', '', 0),
(124, 1, '2018-05-15 19:13:21', '2018-05-15 19:13:21', '', 'billboard-resource', '', 'inherit', 'open', 'closed', '', 'billboard-resource', '', '', '2018-05-15 19:13:26', '2018-05-15 19:13:26', '', 91, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/billboard-resource.png', 0, 'attachment', 'image/png', 0),
(125, 1, '2018-05-15 19:13:45', '2018-05-15 19:13:45', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2018-05-15 19:13:45', '2018-05-15 19:13:45', '', 91, 'http://leasepilot.dev.cc/91-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2018-05-15 19:14:13', '2018-05-15 19:14:13', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2018-05-15 19:14:13', '2018-05-15 19:14:13', '', 91, 'http://leasepilot.dev.cc/91-revision-v1/', 0, 'revision', '', 0),
(127, 1, '2018-05-15 19:14:26', '2018-05-15 19:14:26', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2018-05-15 19:14:26', '2018-05-15 19:14:26', '', 91, 'http://leasepilot.dev.cc/91-revision-v1/', 0, 'revision', '', 0),
(128, 1, '2018-05-15 19:14:49', '2018-05-15 19:14:49', '', 'Resources:', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2018-05-15 19:14:49', '2018-05-15 19:14:49', '', 91, 'http://leasepilot.dev.cc/91-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2018-05-15 19:14:59', '2018-05-15 19:14:59', '', 'Case Studies:', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2018-05-15 19:14:59', '2018-05-15 19:14:59', '', 87, 'http://leasepilot.dev.cc/87-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2018-05-15 19:15:13', '2018-05-15 19:15:13', '', 'Case Studies', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2018-05-15 19:15:13', '2018-05-15 19:15:13', '', 87, 'http://leasepilot.dev.cc/87-revision-v1/', 0, 'revision', '', 0),
(131, 1, '2018-05-15 19:15:17', '2018-05-15 19:15:17', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2018-05-15 19:15:17', '2018-05-15 19:15:17', '', 91, 'http://leasepilot.dev.cc/91-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2018-05-15 19:17:39', '2018-05-15 19:17:39', 'a:7:{s:8:"location";a:2:{i:0;a:1:{i:0;a:3:{s:5:"param";s:8:"taxonomy";s:8:"operator";s:2:"==";s:5:"value";s:17:"resource-category";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:8:"taxonomy";s:8:"operator";s:2:"==";s:5:"value";s:8:"category";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Resource Category Fields', 'resource-category-fields', 'publish', 'closed', 'closed', '', 'group_5afb31f247d7c', '', '', '2018-05-15 19:17:39', '2018-05-15 19:17:39', '', 0, 'http://leasepilot.dev.cc/?post_type=acf-field-group&#038;p=132', 0, 'acf-field-group', '', 0),
(133, 1, '2018-05-15 19:17:39', '2018-05-15 19:17:39', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Category Avatar', 'category_avatar', 'publish', 'closed', 'closed', '', 'field_5afb320ea465a', '', '', '2018-05-15 19:17:39', '2018-05-15 19:17:39', '', 132, 'http://leasepilot.dev.cc/?post_type=acf-field&p=133', 0, 'acf-field', '', 0),
(134, 1, '2018-05-15 19:17:59', '2018-05-15 19:17:59', '', 'resource-case-study', '', 'inherit', 'open', 'closed', '', 'resource-case-study', '', '', '2018-05-15 19:18:04', '2018-05-15 19:18:04', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/resource-case-study.png', 0, 'attachment', 'image/png', 0),
(135, 1, '2018-05-15 19:17:59', '2018-05-15 19:17:59', '', 'resource-ebook', '', 'inherit', 'open', 'closed', '', 'resource-ebook', '', '', '2018-05-15 19:18:14', '2018-05-15 19:18:14', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/resource-ebook.png', 0, 'attachment', 'image/png', 0),
(136, 1, '2018-05-15 19:17:59', '2018-05-15 19:17:59', '', 'resource-teer-sheet', '', 'inherit', 'open', 'closed', '', 'resource-teer-sheet', '', '', '2018-05-15 19:18:28', '2018-05-15 19:18:28', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/resource-teer-sheet.png', 0, 'attachment', 'image/png', 0),
(137, 1, '2018-05-15 23:51:11', '2018-05-15 23:51:11', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:8:"resource";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Resource CPT', 'resource-cpt', 'publish', 'closed', 'closed', '', 'group_5afb724b31fe4', '', '', '2018-05-15 23:51:11', '2018-05-15 23:51:11', '', 0, 'http://leasepilot.dev.cc/?post_type=acf-field-group&#038;p=137', 0, 'acf-field-group', '', 0),
(138, 1, '2018-05-15 23:51:11', '2018-05-15 23:51:11', 'a:10:{s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:8:"min_size";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Download File', 'download_file', 'publish', 'closed', 'closed', '', 'field_5afb7255bce6e', '', '', '2018-05-15 23:51:11', '2018-05-15 23:51:11', '', 137, 'http://leasepilot.dev.cc/?post_type=acf-field&p=138', 0, 'acf-field', '', 0),
(139, 1, '2018-05-15 23:54:12', '2018-05-15 23:54:12', '', 'LeasePilot_PPT_Temp', '', 'inherit', 'open', 'closed', '', 'leasepilot_ppt_temp', '', '', '2018-05-15 23:54:12', '2018-05-15 23:54:12', '', 123, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/LeasePilot_PPT_Temp.pptx', 0, 'attachment', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 0),
(140, 1, '2018-05-16 13:28:57', '2018-05-16 13:28:57', 'asdsadasdasd', 'About us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-16 13:28:57', '2018-05-16 13:28:57', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(141, 1, '2018-05-16 13:30:14', '2018-05-16 13:30:14', '', 'About us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-16 13:30:14', '2018-05-16 13:30:14', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(142, 1, '2018-05-16 13:32:02', '2018-05-16 13:32:02', 'asdasdasdasdasd', 'About us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-16 13:32:02', '2018-05-16 13:32:02', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(143, 1, '2018-05-16 13:33:44', '2018-05-16 13:33:44', '', 'About us', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-05-16 13:33:44', '2018-05-16 13:33:44', '', 10, 'http://leasepilot.dev.cc/10-revision-v1/', 0, 'revision', '', 0),
(144, 1, '2018-05-16 13:35:39', '2018-05-16 13:35:39', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2018-05-16 13:36:08', '2018-05-16 13:36:08', '', 0, 'http://leasepilot.dev.cc/?page_id=144', 0, 'page', '', 0),
(145, 1, '2018-05-16 13:35:39', '2018-05-16 13:35:39', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '144-revision-v1', '', '', '2018-05-16 13:35:39', '2018-05-16 13:35:39', '', 144, 'http://leasepilot.dev.cc/144-revision-v1/', 0, 'revision', '', 0),
(146, 1, '2018-05-16 15:42:24', '2018-05-16 15:42:24', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 15:42:24', '2018-05-16 15:42:24', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(147, 1, '2018-05-16 15:46:41', '2018-05-16 15:46:41', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 15:46:41', '2018-05-16 15:46:41', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(148, 1, '2018-05-16 15:50:22', '2018-05-16 15:50:22', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 15:50:22', '2018-05-16 15:50:22', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(149, 1, '2018-05-16 15:52:59', '2018-05-16 15:52:59', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 15:52:59', '2018-05-16 15:52:59', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(150, 1, '2018-05-16 16:02:59', '2018-05-16 16:02:59', '', 'LEA2463_RebrandAssets_Animation_R1_NoLogo', '', 'inherit', 'open', 'closed', '', 'lea2463_rebrandassets_animation_r1_nologo', '', '', '2018-05-16 16:12:26', '2018-05-16 16:12:26', '', 5, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/LEA2463_RebrandAssets_Animation_R1_NoLogo.mp4', 0, 'attachment', 'video/mp4', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(151, 1, '2018-05-16 16:03:18', '2018-05-16 16:03:18', '', 'compare', '', 'inherit', 'open', 'closed', '', 'compare', '', '', '2018-05-16 16:03:18', '2018-05-16 16:03:18', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/compare.png', 0, 'attachment', 'image/png', 0),
(152, 1, '2018-05-16 16:03:19', '2018-05-16 16:03:19', '', 'computer', '', 'inherit', 'open', 'closed', '', 'computer', '', '', '2018-05-16 16:03:19', '2018-05-16 16:03:19', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/computer.png', 0, 'attachment', 'image/png', 0),
(153, 1, '2018-05-16 16:03:19', '2018-05-16 16:03:19', '', 'entrata-w', '', 'inherit', 'open', 'closed', '', 'entrata-w', '', '', '2018-05-16 16:03:19', '2018-05-16 16:03:19', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/entrata-w.png', 0, 'attachment', 'image/png', 0),
(154, 1, '2018-05-16 16:03:20', '2018-05-16 16:03:20', '', 'nestio-w', '', 'inherit', 'open', 'closed', '', 'nestio-w', '', '', '2018-05-16 16:03:20', '2018-05-16 16:03:20', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/nestio-w.png', 0, 'attachment', 'image/png', 0),
(155, 1, '2018-05-16 16:03:20', '2018-05-16 16:03:20', '', 'real-estate-software-w', '', 'inherit', 'open', 'closed', '', 'real-estate-software-w', '', '', '2018-05-16 16:03:20', '2018-05-16 16:03:20', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/real-estate-software-w.png', 0, 'attachment', 'image/png', 0),
(156, 1, '2018-05-16 16:03:20', '2018-05-16 16:03:20', '', 'screenshot_11', '', 'inherit', 'open', 'closed', '', 'screenshot_11', '', '', '2018-05-16 16:03:20', '2018-05-16 16:03:20', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/screenshot_11.png', 0, 'attachment', 'image/png', 0),
(157, 1, '2018-05-16 16:03:20', '2018-05-16 16:03:20', '', 'tailored', '', 'inherit', 'open', 'closed', '', 'tailored', '', '', '2018-05-16 16:03:20', '2018-05-16 16:03:20', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/tailored.png', 0, 'attachment', 'image/png', 0),
(158, 1, '2018-05-16 16:03:21', '2018-05-16 16:03:21', '', 'transform', '', 'inherit', 'open', 'closed', '', 'transform', '', '', '2018-05-16 16:03:21', '2018-05-16 16:03:21', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/transform.png', 0, 'attachment', 'image/png', 0),
(159, 1, '2018-05-16 16:03:22', '2018-05-16 16:03:22', '', 'turbocharge', '', 'inherit', 'open', 'closed', '', 'turbocharge', '', '', '2018-05-16 16:03:22', '2018-05-16 16:03:22', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/turbocharge.png', 0, 'attachment', 'image/png', 0),
(160, 1, '2018-05-16 16:03:23', '2018-05-16 16:03:23', '', 'vts-w', '', 'inherit', 'open', 'closed', '', 'vts-w', '', '', '2018-05-16 16:03:23', '2018-05-16 16:03:23', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/vts-w.png', 0, 'attachment', 'image/png', 0),
(161, 1, '2018-05-16 16:03:23', '2018-05-16 16:03:23', '', 'yardi-w', '', 'inherit', 'open', 'closed', '', 'yardi-w', '', '', '2018-05-16 16:03:23', '2018-05-16 16:03:23', '', 0, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/yardi-w.png', 0, 'attachment', 'image/png', 0),
(162, 1, '2018-05-16 16:12:26', '2018-05-16 16:12:26', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 16:12:26', '2018-05-16 16:12:26', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(163, 1, '2018-05-16 16:37:57', '2018-05-16 16:37:57', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 16:37:57', '2018-05-16 16:37:57', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(164, 1, '2018-05-16 16:40:23', '2018-05-16 16:40:23', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 16:40:23', '2018-05-16 16:40:23', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(165, 1, '2018-05-16 16:42:35', '2018-05-16 16:42:35', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 16:42:35', '2018-05-16 16:42:35', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(166, 1, '2018-05-16 16:43:06', '2018-05-16 16:43:06', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 16:43:06', '2018-05-16 16:43:06', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(167, 1, '2018-05-16 16:43:35', '2018-05-16 16:43:35', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 16:43:35', '2018-05-16 16:43:35', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(168, 1, '2018-05-16 17:09:56', '2018-05-16 17:09:56', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 17:09:56', '2018-05-16 17:09:56', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(169, 1, '2018-05-16 17:25:42', '2018-05-16 17:25:42', 'a:7:{s:4:"type";s:12:"color_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf3fa78113";s:13:"default_value";s:7:"#ffffff";}', 'Text Color', 'text_color', 'publish', 'closed', 'closed', '', 'field_5afc696ed6bbe', '', '', '2018-05-16 17:31:04', '2018-05-16 17:31:04', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&#038;p=169', 7, 'acf-field', '', 0),
(170, 1, '2018-05-16 17:31:03', '2018-05-16 17:31:03', 'a:13:{s:4:"type";s:5:"radio";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"5afaf3fa78113";s:7:"choices";a:2:{s:6:"center";s:6:"Center";s:6:"bottom";s:6:"Bottom";}s:10:"allow_null";i:0;s:12:"other_choice";i:0;s:17:"save_other_choice";i:0;s:13:"default_value";s:6:"center";s:6:"layout";s:8:"vertical";s:13:"return_format";s:5:"value";}', 'Image Vertical Align', 'image_vertical_align', 'publish', 'closed', 'closed', '', 'field_5afc6a8b48683', '', '', '2018-05-16 17:31:03', '2018-05-16 17:31:03', '', 100, 'http://leasepilot.dev.cc/?post_type=acf-field&p=170', 1, 'acf-field', '', 0),
(171, 1, '2018-05-16 17:37:25', '2018-05-16 17:37:25', '', 'home-cta', '', 'inherit', 'open', 'closed', '', 'home-cta', '', '', '2018-05-16 17:37:26', '2018-05-16 17:37:26', '', 5, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/home-cta.png', 0, 'attachment', 'image/png', 0),
(172, 1, '2018-05-16 17:38:36', '2018-05-16 17:38:36', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 17:38:36', '2018-05-16 17:38:36', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0),
(173, 1, '2018-05-16 18:32:02', '2018-05-16 18:32:02', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_5af83c494f983";s:8:"operator";s:2:"==";s:5:"value";s:5:"video";}}}}', 'Background Video Poster', 'background_video_poster', 'publish', 'closed', 'closed', '', 'field_5afc7907d71fd', '', '', '2018-05-16 18:32:02', '2018-05-16 18:32:02', '', 50, 'http://leasepilot.dev.cc/?post_type=acf-field&p=173', 6, 'acf-field', '', 0),
(174, 1, '2018-05-16 18:32:22', '2018-05-16 18:32:22', '', 'video-poster', '', 'inherit', 'open', 'closed', '', 'video-poster', '', '', '2018-05-16 18:32:25', '2018-05-16 18:32:25', '', 5, 'http://leasepilot.dev.cc/wp-content/uploads/2018/05/video-poster.png', 0, 'attachment', 'image/png', 0),
(175, 1, '2018-05-16 18:32:29', '2018-05-16 18:32:29', '', 'Home', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-16 18:32:29', '2018-05-16 18:32:29', '', 5, 'http://leasepilot.dev.cc/5-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_termmeta`
--

INSERT INTO `wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 5, 'category_avatar', '134'),
(2, 5, '_category_avatar', 'field_5afb320ea465a'),
(3, 4, 'category_avatar', '135'),
(4, 4, '_category_avatar', 'field_5afb320ea465a'),
(5, 3, 'category_avatar', '136'),
(6, 3, '_category_avatar', 'field_5afb320ea465a');

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main Menu', 'main-menu', 0),
(3, 'Tear Sheet', 'tear-sheet', 0),
(4, 'EBook', 'ebook', 0),
(5, 'Case Study', 'case-study', 0),
(6, 'Top Menu', 'top-menu', 0),
(7, 'Product', 'product', 0),
(8, 'About', 'about', 0),
(9, 'Case Studies', 'case-studies', 0),
(10, 'Resources', 'resources', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(12, 5, 0),
(13, 2, 0),
(14, 2, 0),
(17, 2, 0),
(22, 6, 0),
(40, 2, 0),
(41, 7, 0),
(42, 7, 0),
(43, 7, 0),
(44, 7, 0),
(45, 8, 0),
(46, 8, 0),
(47, 9, 0),
(48, 10, 0),
(70, 2, 0),
(90, 2, 0),
(93, 2, 0),
(116, 3, 0),
(117, 4, 0),
(118, 5, 0),
(119, 4, 0),
(120, 4, 0),
(121, 3, 0),
(122, 4, 0),
(123, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 7),
(3, 3, 'resource-category', '', 0, 2),
(4, 4, 'resource-category', '', 0, 4),
(5, 5, 'resource-category', '', 0, 3),
(6, 6, 'nav_menu', '', 0, 1),
(7, 7, 'nav_menu', '', 0, 4),
(8, 8, 'nav_menu', '', 0, 2),
(9, 9, 'nav_menu', '', 0, 1),
(10, 10, 'nav_menu', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:2:{s:64:"3563855b1e417f56e2f0f5e39f138ac3c0285dede339cb0e2c498b2c3d25805c";a:4:{s:10:"expiration";i:1526672510;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36";s:5:"login";i:1525462910;}s:64:"1aa4acd0801c892dc62532e28ab18e4ba6917d18833da055a9ea85d8d8a10d63";a:4:{s:10:"expiration";i:1527558567;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36";s:5:"login";i:1526348967;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '23'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(19, 1, 'closedpostboxes_case_study', 'a:0:{}'),
(20, 1, 'metaboxhidden_case_study', 'a:2:{i:0;s:10:"postcustom";i:1;s:7:"slugdiv";}'),
(21, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:15:"title-attribute";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:24:"add-post-type-case_study";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(23, 1, 'nav_menu_recently_edited', '2'),
(24, 1, 'closedpostboxes_case-study', 'a:0:{}'),
(25, 1, 'metaboxhidden_case-study', 'a:2:{i:0;s:10:"postcustom";i:1;s:7:"slugdiv";}'),
(26, 1, 'wp_user-settings', 'libraryContent=browse&editor=html&hidetb=1'),
(27, 1, 'wp_user-settings-time', '1526488981'),
(28, 1, 'acf_user_settings', 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$B8AoWEVrEwohmlFBIMdzRWNz.usTKo/', 'admin', 'tu@delindesign.com', '', '2018-05-02 18:19:49', '', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=396;
--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1183;
--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=176;
--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
